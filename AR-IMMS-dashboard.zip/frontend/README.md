# AR-IMMS Frontend

Web Management Portal được xây dựng bằng Next.js 16, React 19 và TypeScript.

## 1. Yêu cầu

- Node.js 24 trở lên (khuyến nghị dùng cùng phiên bản với Backend).
- npm.
- Backend AR-IMMS đã chạy và database đã migration/seed.

## 2. Cài đặt

Chạy lệnh tại thư mục `frontend/`:

```powershell
npm ci
Copy-Item .env.example .env.local
```

Mở `.env.local` và cấu hình địa chỉ Backend:

```dotenv
NEXT_PUBLIC_API_URL=http://localhost:3000
```

Không đưa `.env.local` lên Git. Biến `NEXT_PUBLIC_API_URL` chỉ chứa địa chỉ API công khai, không đặt JWT secret, database password hoặc secret Backend tại đây.

## 3. Chạy ứng dụng

```powershell
npm run dev -- --port 3001
```

Mở <http://localhost:3001>. Backend mặc định chạy tại <http://localhost:3000>. CORS Backend cần cho phép origin `http://localhost:3001`.

## 4. Dashboard

Sau khi đăng nhập, Dashboard xác minh phiên bằng `GET /auth/me` và lấy dữ liệu bằng các API có JWT:

| API | Dữ liệu sử dụng |
|---|---|
| `GET /sites` | Tổng số Site, thông tin Site |
| `GET /rooms` | Tổng số Room, liên kết Site |
| `GET /racks` | Tổng số Rack, liên kết Room |
| `GET /assets` | Node/Server, Rack, Workload |

Dashboard hiện có các thẻ tổng hợp số lượng Site/Room/Rack/Node, biểu đồ cơ cấu hạ tầng, cây Site → Room → Rack → Node, bảng Node/Server có tìm kiếm, thời điểm cập nhật và thao tác tải lại dữ liệu. Các trạng thái loading, lỗi kết nối, phiên hết hạn (401), không đủ quyền (403) và dữ liệu rỗng được xử lý ở giao diện.

### Giới hạn dữ liệu giám sát

Backend hiện chưa có schema/API trạng thái Online/Offline, telemetry hoặc alert. Dashboard đánh dấu các khu vực đó là **chưa tích hợp dữ liệu**, không tự sinh số liệu giả. Để bật biểu đồ CPU/RAM/nhiệt độ/network và thống kê cảnh báo, cần triển khai Collector Agent, lưu trữ telemetry, mô hình cảnh báo và API truy vấn tương ứng ở Backend.

## 5. Phiên đăng nhập và bảo mật

- Access token và role được lưu trong `sessionStorage`; đóng tab/session sẽ kết thúc phiên Frontend.
- Mỗi request cần bảo vệ gửi token qua `Authorization: Bearer <token>`.
- Logout xóa access token và role khỏi `sessionStorage`, sau đó chuyển về trang đăng nhập.
- Dashboard xác minh token lại khi tải trang; token hết hạn sẽ xóa phiên và điều hướng về trang đăng nhập.
- Không ghi mật khẩu hoặc access token vào console/log.
- Việc ẩn menu trên Frontend không thay thế kiểm tra RBAC của Backend.

## 6. Kiểm tra

```powershell
npm run lint
npm run build
```

Kiểm tra thủ công sau khi Backend và Frontend cùng chạy:

1. Đăng nhập bằng Administrator, Operator và Technician.
2. Xác nhận các thẻ Site/Room/Rack/Node khớp dữ liệu Backend.
3. Thử ô tìm Node/Server và nút Làm mới dữ liệu.
4. Thử dừng Backend để kiểm tra thông báo lỗi và nút thử lại.
5. Logout, sau đó truy cập trực tiếp `/dashboard`; người dùng phải bị chuyển về `/`.
6. Kiểm tra token hết hạn/không hợp lệ dẫn về trang đăng nhập.

## 7. Build và chạy production

```powershell
npm run build
npm run start -- --port 3001
```
