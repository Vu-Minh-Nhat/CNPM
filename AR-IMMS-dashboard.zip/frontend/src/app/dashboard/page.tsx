"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import type { ReactNode } from "react";
import { useRouter } from "next/navigation";
import {
  clearSession,
  getAccessToken,
  getCurrentUser,
} from "@/lib/auth";
import {
  countWorkloads,
  DashboardApiError,
  getDashboardData,
  type AssetNode,
  type CurrentUser,
  type DashboardData,
  type Rack,
  type Room,
  type Site,
} from "@/lib/dashboard";

type IconName =
  | "grid"
  | "building"
  | "layers"
  | "server"
  | "activity"
  | "bell"
  | "refresh"
  | "logout"
  | "search"
  | "chevron"
  | "database"
  | "shield"
  | "clock"
  | "box";

function Icon({ name, size = 20 }: { name: IconName; size?: number }) {
  const common = {
    width: size,
    height: size,
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: 1.8,
    strokeLinecap: "round" as const,
    strokeLinejoin: "round" as const,
    "aria-hidden": true as const,
  };

  const paths: Record<IconName, ReactNode> = {
    grid: <><rect x="3" y="3" width="7" height="7" rx="1.5" /><rect x="14" y="3" width="7" height="7" rx="1.5" /><rect x="3" y="14" width="7" height="7" rx="1.5" /><rect x="14" y="14" width="7" height="7" rx="1.5" /></>,
    building: <><path d="M3 21h18" /><path d="M5 21V5l7-2v18" /><path d="M12 8h7v13" /><path d="M8 7h1M8 11h1M8 15h1M15 12h1M18 12h1M15 16h1M18 16h1" /></>,
    layers: <><path d="m12 3 9 5-9 5-9-5 9-5Z" /><path d="m3 12 9 5 9-5" /><path d="m3 16 9 5 9-5" /></>,
    server: <><rect x="3" y="3" width="18" height="8" rx="2" /><rect x="3" y="13" width="18" height="8" rx="2" /><path d="M7 7h.01M7 17h.01M11 7h6M11 17h6" /></>,
    activity: <><path d="M3 12h4l3-8 4 16 3-8h4" /></>,
    bell: <><path d="M18 8a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9" /><path d="M10 21h4" /></>,
    refresh: <><path d="M20 7v5h-5" /><path d="M4 17v-5h5" /><path d="M5.6 9A7 7 0 0 1 18 6l2 6M4 12l2 6a7 7 0 0 0 12.4-3" /></>,
    logout: <><path d="M10 17l5-5-5-5" /><path d="M15 12H3" /><path d="M12 3h6a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-6" /></>,
    search: <><circle cx="10.8" cy="10.8" r="6.8" /><path d="m16 16 5 5" /></>,
    chevron: <path d="m9 18 6-6-6-6" />,
    database: <><ellipse cx="12" cy="5" rx="8" ry="3" /><path d="M4 5v14c0 1.7 3.6 3 8 3s8-1.3 8-3V5" /><path d="M4 12c0 1.7 3.6 3 8 3s8-1.3 8-3" /></>,
    shield: <><path d="M12 22s8-4 8-11V5l-8-3-8 3v6c0 7 8 11 8 11Z" /><path d="m9 12 2 2 4-4" /></>,
    clock: <><circle cx="12" cy="12" r="9" /><path d="M12 7v5l3 2" /></>,
    box: <><path d="m12 3 9 5v8l-9 5-9-5V8l9-5Z" /><path d="m3.5 8.2 8.5 4.9 8.5-4.9M12 13v8" /></>,
  };

  return <svg {...common}>{paths[name]}</svg>;
}

function formatNumber(value: number) {
  return new Intl.NumberFormat("vi-VN").format(value);
}

function SectionHeading({
  eyebrow,
  title,
  description,
}: {
  eyebrow?: string;
  title: string;
  description?: string;
}) {
  return (
    <div className="mb-5">
      {eyebrow && (
        <p className="mb-1 text-[10px] font-bold uppercase tracking-[0.18em] text-cyan-700">
          {eyebrow}
        </p>
      )}
      <h2 className="text-lg font-bold tracking-tight text-slate-900">{title}</h2>
      {description && <p className="mt-1 text-sm text-slate-500">{description}</p>}
    </div>
  );
}

function MetricCard({
  label,
  value,
  detail,
  icon,
  tone,
}: {
  label: string;
  value: number;
  detail: string;
  icon: IconName;
  tone: "cyan" | "blue" | "violet" | "amber";
}) {
  const tones = {
    cyan: "bg-cyan-50 text-cyan-700 ring-cyan-100",
    blue: "bg-blue-50 text-blue-700 ring-blue-100",
    violet: "bg-violet-50 text-violet-700 ring-violet-100",
    amber: "bg-amber-50 text-amber-700 ring-amber-100",
  };

  return (
    <article className="rounded-2xl border border-slate-200/80 bg-white p-5 shadow-[0_4px_18px_rgba(15,23,42,0.035)] transition hover:-translate-y-0.5 hover:shadow-md">
      <div className="flex items-start justify-between gap-3">
        <div>
          <p className="text-sm font-medium text-slate-500">{label}</p>
          <p className="mt-3 text-3xl font-bold tracking-tight text-slate-950">{formatNumber(value)}</p>
        </div>
        <div className={`rounded-xl p-3 ring-1 ${tones[tone]}`}>
          <Icon name={icon} size={21} />
        </div>
      </div>
      <p className="mt-4 text-xs text-slate-500">{detail}</p>
    </article>
  );
}

function EmptyModule({
  icon,
  title,
  description,
  status,
}: {
  icon: IconName;
  title: string;
  description: string;
  status: string;
}) {
  return (
    <article className="rounded-2xl border border-dashed border-slate-300 bg-slate-50/80 p-5">
      <div className="flex items-start justify-between gap-3">
        <div className="rounded-xl bg-white p-2.5 text-slate-500 shadow-sm ring-1 ring-slate-200">
          <Icon name={icon} />
        </div>
        <span className="rounded-full bg-slate-200/80 px-2.5 py-1 text-[10px] font-bold uppercase tracking-wide text-slate-600">
          {status}
        </span>
      </div>
      <h3 className="mt-4 text-sm font-bold text-slate-800">{title}</h3>
      <p className="mt-1.5 text-xs leading-5 text-slate-500">{description}</p>
    </article>
  );
}

function AssetTree({
  sites,
  rooms,
  racks,
  assets,
}: {
  sites: Site[];
  rooms: Room[];
  racks: Rack[];
  assets: AssetNode[];
}) {
  if (sites.length === 0) {
    return (
      <div className="rounded-xl border border-dashed border-slate-200 px-5 py-10 text-center">
        <Icon name="building" size={28} />
        <p className="mt-3 text-sm font-semibold text-slate-700">Chưa có Site</p>
        <p className="mt-1 text-xs text-slate-500">Dữ liệu hạ tầng sẽ xuất hiện tại đây sau khi được tạo trong hệ thống.</p>
      </div>
    );
  }

  return (
    <div className="space-y-3">
      {sites.map((site) => {
        const siteRooms = rooms.filter((room) => room.siteId === site.id);
        const siteRackCount = racks.filter((rack) => siteRooms.some((room) => room.id === rack.roomId)).length;
        const siteAssetCount = assets.filter((asset) => racks.some((rack) => rack.id === asset.rackId && siteRooms.some((room) => room.id === rack.roomId))).length;

        return (
          <details key={site.id} className="group rounded-xl border border-slate-200 bg-white" open={sites.length === 1}>
            <summary className="flex cursor-pointer list-none items-center gap-3 px-4 py-3.5 marker:hidden">
              <span className="rounded-lg bg-cyan-50 p-2 text-cyan-700"><Icon name="building" size={17} /></span>
              <span className="min-w-0 flex-1">
                <span className="block truncate text-sm font-semibold text-slate-800">{site.name}</span>
                <span className="mt-0.5 block text-[11px] text-slate-500">{site.code}</span>
              </span>
              <span className="hidden text-xs text-slate-500 sm:block">{siteRooms.length} Room · {siteRackCount} Rack · {siteAssetCount} Node</span>
              <span className="text-slate-400 transition group-open:rotate-90"><Icon name="chevron" size={16} /></span>
            </summary>
            <div className="border-t border-slate-100 px-4 py-3">
              {siteRooms.length === 0 ? (
                <p className="py-2 pl-10 text-xs text-slate-500">Site này chưa có Room.</p>
              ) : (
                <div className="space-y-3">
                  {siteRooms.map((room) => {
                    const roomRacks = racks.filter((rack) => rack.roomId === room.id);
                    return (
                      <div key={room.id} className="ml-2 border-l-2 border-slate-100 pl-4">
                        <div className="flex flex-wrap items-center gap-2 py-1">
                          <Icon name="layers" size={15} />
                          <span className="text-xs font-semibold text-slate-700">{room.name}</span>
                          <span className="text-[10px] text-slate-400">{room.code}</span>
                        </div>
                        {roomRacks.length === 0 ? (
                          <p className="py-1 pl-6 text-[11px] text-slate-400">Chưa có Rack.</p>
                        ) : (
                          <div className="mt-1 space-y-2 pl-5">
                            {roomRacks.map((rack) => {
                              const rackAssets = assets.filter((asset) => asset.rackId === rack.id);
                              return (
                                <div key={rack.id} className="rounded-lg bg-slate-50 px-3 py-2">
                                  <div className="flex items-center justify-between gap-3">
                                    <span className="flex items-center gap-2 text-xs font-medium text-slate-700"><Icon name="server" size={14} />{rack.name} <span className="text-slate-400">({rack.code})</span></span>
                                    <span className="text-[10px] text-slate-500">{rackAssets.length} Node</span>
                                  </div>
                                  {rackAssets.length > 0 && (
                                    <div className="mt-2 flex flex-wrap gap-1.5 pl-5">
                                      {rackAssets.map((asset) => <span key={asset.id} className="rounded-md border border-slate-200 bg-white px-2 py-1 text-[10px] text-slate-600">{asset.code}</span>)}
                                    </div>
                                  )}
                                </div>
                              );
                            })}
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          </details>
        );
      })}
    </div>
  );
}

export default function DashboardPage() {
  const router = useRouter();
  const [checking, setChecking] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [user, setUser] = useState<CurrentUser | null>(null);
  const [data, setData] = useState<DashboardData | null>(null);
  const [error, setError] = useState("");
  const [lastUpdated, setLastUpdated] = useState("");
  const [search, setSearch] = useState("");

  const loadDashboard = useCallback(async (isRefresh = false) => {
    const token = getAccessToken();
    if (!token) {
      clearSession();
      router.replace("/");
      return;
    }

    if (isRefresh) setRefreshing(true);
    else setChecking(true);
    setError("");

    try {
      const [currentUser, dashboardData] = await Promise.all([
        getCurrentUser(token) as Promise<CurrentUser>,
        getDashboardData(token),
      ]);
      setUser(currentUser);
      setData(dashboardData);
      setLastUpdated(new Intl.DateTimeFormat("vi-VN", {
        dateStyle: "medium",
        timeStyle: "short",
      }).format(new Date()));
    } catch (cause) {
      const message = cause instanceof Error ? cause.message : "Không thể tải dữ liệu Dashboard.";
      const status = cause instanceof DashboardApiError ? cause.status : undefined;

      if (status === 401 || message === "Phiên đăng nhập đã hết hạn.") {
        clearSession();
        router.replace("/");
        return;
      }

      setError(status === 403 ? "Tài khoản của bạn không có quyền xem một hoặc nhiều nhóm dữ liệu Dashboard." : message);
    } finally {
      setChecking(false);
      setRefreshing(false);
    }
  }, [router]);

  useEffect(() => {
    void loadDashboard();
  }, [loadDashboard]);

  const filteredAssets = useMemo(() => {
    if (!data) return [];
    const keyword = search.trim().toLowerCase();
    if (!keyword) return data.assets;
    return data.assets.filter((asset) =>
      [asset.code, asset.name, asset.serialNumber ?? ""].some((value) => value.toLowerCase().includes(keyword)),
    );
  }, [data, search]);

  const counts = useMemo(() => {
    if (!data) return [];
    return [
      { label: "Site", value: data.sites.length, color: "bg-cyan-600" },
      { label: "Room", value: data.rooms.length, color: "bg-blue-600" },
      { label: "Rack", value: data.racks.length, color: "bg-violet-600" },
      { label: "Node / Server", value: data.assets.length, color: "bg-amber-500" },
    ];
  }, [data]);
  const maxCount = Math.max(1, ...counts.map((item) => item.value));
  const totalWorkloads = data ? countWorkloads(data.assets) : 0;

  function handleLogout() {
    clearSession();
    router.replace("/");
  }

  if (checking) {
    return (
      <main className="flex min-h-screen items-center justify-center bg-[#f4f7fb] px-6">
        <div className="text-center">
          <div className="mx-auto h-10 w-10 animate-spin rounded-full border-4 border-cyan-100 border-t-cyan-700" />
          <p className="mt-4 text-sm font-medium text-slate-600">Đang xác minh phiên và tải dữ liệu hạ tầng...</p>
        </div>
      </main>
    );
  }

  if (error && !data) {
    return (
      <main className="flex min-h-screen items-center justify-center bg-[#f4f7fb] px-6">
        <section className="w-full max-w-lg rounded-2xl border border-slate-200 bg-white p-8 text-center shadow-sm">
          <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-xl bg-rose-50 text-rose-600"><Icon name="activity" size={24} /></div>
          <h1 className="mt-4 text-xl font-bold text-slate-900">Không thể tải Dashboard</h1>
          <p className="mt-2 text-sm leading-6 text-slate-500">{error}</p>
          <div className="mt-6 flex flex-wrap justify-center gap-3">
            <button onClick={() => void loadDashboard()} className="rounded-xl bg-cyan-700 px-5 py-2.5 text-sm font-semibold text-white hover:bg-cyan-800">Thử tải lại</button>
            <button onClick={handleLogout} className="rounded-xl border border-slate-200 px-5 py-2.5 text-sm font-semibold text-slate-700 hover:bg-slate-50">Đăng xuất</button>
          </div>
        </section>
      </main>
    );
  }

  if (!data) return null;

  const firstName = user?.email?.split("@")[0] ?? "User";
  const roleLabel = user?.role ?? "Người dùng";

  return (
    <div className="min-h-screen bg-[#f4f7fb] text-slate-800">
      <aside className="fixed inset-y-0 left-0 z-30 hidden w-[248px] flex-col bg-[#0b2033] text-white lg:flex">
        <div className="flex h-[82px] items-center gap-3 border-b border-white/10 px-6">
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-cyan-500 text-sm font-black tracking-tight text-[#062033]">AR</div>
          <div>
            <p className="text-[15px] font-extrabold tracking-wide">AR-IMMS</p>
            <p className="mt-0.5 text-[9px] font-semibold tracking-[0.17em] text-cyan-300">INFRASTRUCTURE</p>
          </div>
        </div>

        <div className="px-4 pt-7">
          <p className="px-3 text-[9px] font-bold uppercase tracking-[0.2em] text-slate-500">Workspace</p>
          <nav className="mt-3 space-y-1">
            <a href="#overview" className="flex items-center gap-3 rounded-xl bg-cyan-500/15 px-3 py-3 text-sm font-semibold text-cyan-300 ring-1 ring-inset ring-cyan-400/15"><Icon name="grid" size={18} />Tổng quan</a>
            <a href="#inventory" className="flex items-center gap-3 rounded-xl px-3 py-3 text-sm font-medium text-slate-300 transition hover:bg-white/5 hover:text-white"><Icon name="server" size={18} />Tài sản hạ tầng</a>
            <a href="#monitoring" className="flex items-center gap-3 rounded-xl px-3 py-3 text-sm font-medium text-slate-300 transition hover:bg-white/5 hover:text-white"><Icon name="activity" size={18} />Giám sát</a>
            <a href="#alerts" className="flex items-center gap-3 rounded-xl px-3 py-3 text-sm font-medium text-slate-300 transition hover:bg-white/5 hover:text-white"><Icon name="bell" size={18} />Cảnh báo</a>
          </nav>
        </div>

        <div className="mt-auto border-t border-white/10 p-4">
          <div className="rounded-xl bg-white/[0.06] p-3">
            <div className="flex items-center gap-2">
              <span className="h-2 w-2 rounded-full bg-emerald-400" />
              <span className="text-[11px] font-semibold text-slate-200">Backend API đã kết nối</span>
            </div>
            <p className="mt-2 truncate text-[10px] text-slate-400">{user?.email}</p>
            <p className="mt-1 text-[10px] text-cyan-300">{roleLabel}</p>
          </div>
          <button onClick={handleLogout} className="mt-3 flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium text-slate-300 transition hover:bg-rose-500/10 hover:text-rose-300"><Icon name="logout" size={18} />Đăng xuất</button>
        </div>
      </aside>

      <div className="lg:pl-[248px]">
        <header className="sticky top-0 z-20 flex h-[72px] items-center justify-between border-b border-slate-200/80 bg-white/90 px-5 backdrop-blur-xl sm:px-8">
          <div className="flex items-center gap-3">
            <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-[#0b2033] text-xs font-black text-cyan-300 lg:hidden">AR</div>
            <div>
              <p className="text-sm font-bold text-slate-900">Infrastructure Overview</p>
              <p className="hidden text-[11px] text-slate-500 sm:block">AR-IMMS / Web Management Portal</p>
            </div>
          </div>
          <div className="flex items-center gap-3 sm:gap-5">
            <div className="hidden items-center gap-2 rounded-full border border-emerald-100 bg-emerald-50 px-3 py-1.5 sm:flex"><span className="status-light h-1.5 w-1.5 rounded-full bg-emerald-500" /><span className="text-[11px] font-semibold text-emerald-700">API Connected</span></div>
            <div className="hidden text-right sm:block"><p className="text-xs font-semibold text-slate-800">{user?.email}</p><p className="mt-0.5 text-[10px] text-slate-500">{roleLabel}</p></div>
            <button onClick={handleLogout} className="flex items-center gap-2 rounded-lg border border-slate-200 px-3 py-2 text-xs font-semibold text-slate-600 transition hover:border-rose-200 hover:bg-rose-50 hover:text-rose-700 lg:hidden"><Icon name="logout" size={15} />Thoát</button>
          </div>
        </header>

        <main id="overview" className="mx-auto max-w-[1500px] px-5 py-7 sm:px-8 sm:py-9">
          <nav className="mb-6 flex gap-2 overflow-x-auto pb-1 lg:hidden" aria-label="Điều hướng Dashboard">
            {[{ href: "#overview", label: "Tổng quan" }, { href: "#inventory", label: "Tài sản" }, { href: "#monitoring", label: "Giám sát" }, { href: "#alerts", label: "Cảnh báo" }].map((item) => (
              <a key={item.href} href={item.href} className="shrink-0 rounded-lg border border-slate-200 bg-white px-3 py-2 text-[11px] font-semibold text-slate-600 hover:border-cyan-200 hover:text-cyan-800">{item.label}</a>
            ))}
          </nav>
          <section className="mb-7 flex flex-col justify-between gap-4 md:flex-row md:items-end">
            <div>
              <p className="text-[10px] font-bold uppercase tracking-[0.2em] text-cyan-700">System overview</p>
              <h1 className="mt-2 text-2xl font-extrabold tracking-tight text-slate-950 sm:text-[30px]">Tổng quan hạ tầng</h1>
              <p className="mt-2 text-sm text-slate-500">Xin chào <span className="font-semibold text-slate-700">{firstName}</span>, đây là tình hình tài sản đang được quản lý.</p>
            </div>
            <div className="flex flex-wrap items-center gap-3">
              <div className="flex items-center gap-2 text-[11px] text-slate-500"><Icon name="clock" size={15} />Cập nhật: {lastUpdated || "Vừa tải"}</div>
              <button onClick={() => void loadDashboard(true)} disabled={refreshing} className="inline-flex items-center gap-2 rounded-xl border border-slate-200 bg-white px-4 py-2.5 text-xs font-bold text-slate-700 shadow-sm transition hover:border-cyan-200 hover:text-cyan-800 disabled:cursor-not-allowed disabled:opacity-60"><span className={refreshing ? "animate-spin" : ""}><Icon name="refresh" size={15} /></span>{refreshing ? "Đang cập nhật" : "Làm mới dữ liệu"}</button>
            </div>
          </section>

          {error && <div role="alert" className="mb-5 rounded-xl border border-amber-200 bg-amber-50 px-4 py-3 text-xs text-amber-800">Một số dữ liệu chưa tải được: {error}</div>}

          <section className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
            <MetricCard label="Tổng số Site" value={data.sites.length} detail="Địa điểm hạ tầng" icon="building" tone="cyan" />
            <MetricCard label="Tổng số Room" value={data.rooms.length} detail="Phòng thuộc các Site" icon="layers" tone="blue" />
            <MetricCard label="Tổng số Rack" value={data.racks.length} detail="Tủ rack trong hệ thống" icon="box" tone="violet" />
            <MetricCard label="Tổng Node / Server" value={data.assets.length} detail={`${formatNumber(totalWorkloads)} Workload được liên kết`} icon="server" tone="amber" />
          </section>

          <section className="mt-7 grid gap-5 xl:grid-cols-[1.15fr_0.85fr]">
            <article className="rounded-2xl border border-slate-200/80 bg-white p-5 shadow-[0_4px_18px_rgba(15,23,42,0.035)] sm:p-6">
              <SectionHeading eyebrow="Inventory analytics" title="Cơ cấu tài sản" description="Phân bổ số lượng theo từng cấp hạ tầng · dữ liệu trực tiếp từ Backend." />
              <div className="space-y-5">
                {counts.map((item) => (
                  <div key={item.label}>
                    <div className="mb-2 flex items-center justify-between"><span className="text-xs font-semibold text-slate-600">{item.label}</span><span className="text-xs font-bold tabular-nums text-slate-900">{formatNumber(item.value)}</span></div>
                    <div className="h-2.5 overflow-hidden rounded-full bg-slate-100"><div className={`h-full rounded-full ${item.color} transition-all duration-700`} style={{ width: `${(item.value / maxCount) * 100}%` }} /></div>
                  </div>
                ))}
              </div>
              <div className="mt-6 flex flex-wrap gap-x-5 gap-y-2 border-t border-slate-100 pt-4 text-[10px] text-slate-500"><span>● Số lượng bản ghi thực tế</span><span>● Không dùng dữ liệu mô phỏng</span></div>
            </article>

            <article className="rounded-2xl border border-slate-200/80 bg-white p-5 shadow-[0_4px_18px_rgba(15,23,42,0.035)] sm:p-6">
              <SectionHeading eyebrow="Data integrity" title="Tình trạng dữ liệu" description="Các nhóm dữ liệu hiện được Backend cung cấp." />
              <div className="space-y-3">
                <div className="flex items-center gap-3 rounded-xl bg-emerald-50/70 p-3"><span className="flex h-9 w-9 items-center justify-center rounded-lg bg-white text-emerald-700"><Icon name="database" size={18} /></span><div className="min-w-0 flex-1"><p className="text-xs font-bold text-slate-800">Danh mục hạ tầng</p><p className="mt-0.5 text-[10px] text-slate-500">Site · Room · Rack · Node</p></div><span className="rounded-full bg-emerald-100 px-2.5 py-1 text-[9px] font-bold text-emerald-700">Đã kết nối</span></div>
                <div className="flex items-center gap-3 rounded-xl bg-slate-50 p-3"><span className="flex h-9 w-9 items-center justify-center rounded-lg bg-white text-slate-500"><Icon name="activity" size={18} /></span><div className="min-w-0 flex-1"><p className="text-xs font-bold text-slate-800">Telemetry</p><p className="mt-0.5 text-[10px] text-slate-500">Chưa có API / dữ liệu đo</p></div><span className="rounded-full bg-slate-200 px-2.5 py-1 text-[9px] font-bold text-slate-600">Chưa tích hợp</span></div>
                <div className="flex items-center gap-3 rounded-xl bg-slate-50 p-3"><span className="flex h-9 w-9 items-center justify-center rounded-lg bg-white text-slate-500"><Icon name="bell" size={18} /></span><div className="min-w-0 flex-1"><p className="text-xs font-bold text-slate-800">Alert management</p><p className="mt-0.5 text-[10px] text-slate-500">Chưa có API / dữ liệu cảnh báo</p></div><span className="rounded-full bg-slate-200 px-2.5 py-1 text-[9px] font-bold text-slate-600">Chưa tích hợp</span></div>
                <div className="flex items-center gap-3 rounded-xl bg-slate-50 p-3"><span className="flex h-9 w-9 items-center justify-center rounded-lg bg-white text-slate-500"><Icon name="shield" size={18} /></span><div className="min-w-0 flex-1"><p className="text-xs font-bold text-slate-800">Trạng thái Online / Offline</p><p className="mt-0.5 text-[10px] text-slate-500">Schema Node chưa có trường trạng thái</p></div><span className="rounded-full bg-slate-200 px-2.5 py-1 text-[9px] font-bold text-slate-600">Chưa có dữ liệu</span></div>
              </div>
            </article>
          </section>

          <section id="monitoring" className="mt-7 scroll-mt-24">
            <SectionHeading eyebrow="Monitoring center" title="Giám sát & cảnh báo" description="Khu vực hiển thị sẽ được kích hoạt khi Backend cung cấp dữ liệu telemetry và alert." />
            <div className="grid gap-4 lg:grid-cols-2">
              <div className="rounded-2xl border border-slate-200/80 bg-white p-5 shadow-[0_4px_18px_rgba(15,23,42,0.035)] sm:p-6">
                <div className="flex items-center justify-between"><div className="flex items-center gap-2"><span className="rounded-lg bg-cyan-50 p-2 text-cyan-700"><Icon name="activity" size={18} /></span><h3 className="text-sm font-bold text-slate-900">Telemetry trend</h3></div><span className="rounded-full bg-slate-100 px-2.5 py-1 text-[9px] font-bold text-slate-500">NO DATA SOURCE</span></div>
                <div className="mt-5 flex min-h-[174px] flex-col items-center justify-center rounded-xl border border-dashed border-slate-200 bg-slate-50/70 px-5 text-center">
                  <div className="flex h-11 w-11 items-center justify-center rounded-full bg-white text-slate-400 shadow-sm"><Icon name="activity" size={21} /></div>
                  <p className="mt-3 text-xs font-semibold text-slate-700">Chưa có dữ liệu telemetry</p>
                  <p className="mt-1 max-w-sm text-[10px] leading-5 text-slate-500">Cần tích hợp Collector Agent, lưu trữ metric và API truy vấn theo thời gian trước khi vẽ biểu đồ CPU, RAM, nhiệt độ hoặc network.</p>
                </div>
              </div>
              <div id="alerts" className="scroll-mt-24 rounded-2xl border border-slate-200/80 bg-white p-5 shadow-[0_4px_18px_rgba(15,23,42,0.035)] sm:p-6">
                <div className="flex items-center justify-between"><div className="flex items-center gap-2"><span className="rounded-lg bg-amber-50 p-2 text-amber-700"><Icon name="bell" size={18} /></span><h3 className="text-sm font-bold text-slate-900">Alert summary</h3></div><span className="rounded-full bg-slate-100 px-2.5 py-1 text-[9px] font-bold text-slate-500">NO DATA SOURCE</span></div>
                <div className="mt-5 grid min-h-[174px] grid-cols-3 gap-3">
                  {[{ label: "Critical", color: "text-rose-600", bg: "bg-rose-50" }, { label: "Warning", color: "text-amber-700", bg: "bg-amber-50" }, { label: "Info", color: "text-blue-700", bg: "bg-blue-50" }].map((item) => <div key={item.label} className={`${item.bg} flex flex-col items-center justify-center rounded-xl`}><span className={`text-2xl font-bold ${item.color}`}>—</span><span className="mt-2 text-[10px] font-bold text-slate-600">{item.label}</span><span className="mt-1 text-[9px] text-slate-400">Chưa có dữ liệu</span></div>)}
                </div>
                <p className="mt-3 text-[10px] leading-5 text-slate-500">Không hiển thị số lượng cảnh báo bằng 0 vì hệ thống chưa có nguồn dữ liệu cảnh báo để xác định.</p>
              </div>
            </div>
          </section>

          <section id="inventory" className="mt-7 scroll-mt-24">
            <div className="grid gap-5 xl:grid-cols-[0.95fr_1.05fr]">
              <article className="rounded-2xl border border-slate-200/80 bg-white p-5 shadow-[0_4px_18px_rgba(15,23,42,0.035)] sm:p-6">
                <SectionHeading eyebrow="Asset topology" title="Cấu trúc hạ tầng" description="Site → Room → Rack → Node / Server." />
                <AssetTree sites={data.sites} rooms={data.rooms} racks={data.racks} assets={data.assets} />
              </article>

              <article className="min-w-0 rounded-2xl border border-slate-200/80 bg-white p-5 shadow-[0_4px_18px_rgba(15,23,42,0.035)] sm:p-6">
                <div className="flex flex-col justify-between gap-3 sm:flex-row sm:items-start">
                  <SectionHeading eyebrow="Asset registry" title="Danh sách Node / Server" description={`${formatNumber(data.assets.length)} thiết bị trong dữ liệu Backend.`} />
                  <label className="relative block sm:w-52">
                    <span className="sr-only">Tìm kiếm Node hoặc Server</span>
                    <span className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-slate-400"><Icon name="search" size={15} /></span>
                    <input value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Tìm mã, tên, serial..." className="w-full rounded-lg border border-slate-200 bg-slate-50 py-2 pl-9 pr-3 text-[11px] outline-none transition placeholder:text-slate-400 focus:border-cyan-400 focus:bg-white focus:ring-2 focus:ring-cyan-50" />
                  </label>
                </div>
                <div className="overflow-x-auto">
                  <table className="w-full min-w-[520px] border-collapse text-left">
                    <thead><tr className="border-b border-slate-100 text-[9px] font-bold uppercase tracking-wider text-slate-400"><th className="py-3 pr-3">Node / Server</th><th className="px-3 py-3">Rack</th><th className="px-3 py-3">Serial Number</th><th className="py-3 pl-3 text-right">Workload</th></tr></thead>
                    <tbody>
                      {filteredAssets.length === 0 ? (
                        <tr><td colSpan={4} className="py-10 text-center text-xs text-slate-500">{data.assets.length === 0 ? "Chưa có Node / Server trong hệ thống." : "Không tìm thấy thiết bị phù hợp."}</td></tr>
                      ) : filteredAssets.map((asset) => <tr key={asset.id} className="border-b border-slate-50 last:border-0 hover:bg-slate-50/70"><td className="py-3 pr-3"><p className="text-xs font-semibold text-slate-800">{asset.name}</p><p className="mt-0.5 text-[10px] text-slate-400">{asset.code}</p></td><td className="px-3 py-3 text-[10px] text-slate-600">{data.racks.find((rack) => rack.id === asset.rackId)?.code ?? "—"}</td><td className="px-3 py-3 text-[10px] text-slate-600">{asset.serialNumber || "—"}</td><td className="py-3 pl-3 text-right text-xs font-semibold tabular-nums text-slate-700">{asset.workloads?.length ?? 0}</td></tr>)}
                    </tbody>
                  </table>
                </div>
                <p className="mt-3 text-[9px] text-slate-400">Thông tin lấy từ GET /assets. Không có trạng thái online/offline trong dữ liệu hiện tại.</p>
              </article>
            </div>
          </section>

          <footer className="mt-8 flex flex-col justify-between gap-2 border-t border-slate-200 py-5 text-[10px] text-slate-400 sm:flex-row sm:items-center">
            <p>© 2026 AR-IMMS · Infrastructure Monitoring and Maintenance System</p>
            <p>Signed in as {roleLabel} · Data loaded from PostgreSQL APIs</p>
          </footer>
        </main>
      </div>
    </div>
  );
}
