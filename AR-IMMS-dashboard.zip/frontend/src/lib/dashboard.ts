const API_URL = process.env.NEXT_PUBLIC_API_URL ?? "http://localhost:3000";

export type Site = {
  id: string;
  code: string;
  name: string;
};

export type Room = {
  id: string;
  siteId: string;
  code: string;
  name: string;
};

export type Rack = {
  id: string;
  roomId: string;
  code: string;
  name: string;
  capacityU: number;
};

export type Workload = {
  id: string;
  nodeId: string;
  code: string;
  name: string;
  runtimeId: string | null;
};

export type AssetNode = {
  id: string;
  rackId: string;
  code: string;
  name: string;
  serialNumber: string | null;
  workloads?: Workload[];
};

export type DashboardData = {
  sites: Site[];
  rooms: Room[];
  racks: Rack[];
  assets: AssetNode[];
};

export type CurrentUser = {
  userId: string;
  email: string;
  role: string;
};

export class DashboardApiError extends Error {
  constructor(
    message: string,
    public readonly status: number,
  ) {
    super(message);
    this.name = "DashboardApiError";
  }
}

async function getProtected<T>(path: string, token: string): Promise<T> {
  let response: Response;

  try {
    response = await fetch(`${API_URL}${path}`, {
      method: "GET",
      headers: { Authorization: `Bearer ${token}` },
      cache: "no-store",
    });
  } catch {
    throw new DashboardApiError(
      "Không thể kết nối Backend. Hãy kiểm tra Backend và cấu hình API URL.",
      0,
    );
  }

  const body = await response.json().catch(() => null);
  if (!response.ok) {
    const message = Array.isArray(body?.message)
      ? body.message.join(", ")
      : body?.message;

    throw new DashboardApiError(
      message ||
        (response.status === 401
          ? "Phiên đăng nhập đã hết hạn."
          : response.status === 403
            ? "Tài khoản không có quyền xem dữ liệu này."
            : `Không thể tải ${path} (HTTP ${response.status}).`),
      response.status,
    );
  }

  if (!Array.isArray(body)) {
    throw new DashboardApiError(
      `Dữ liệu trả về từ ${path} không đúng định dạng danh sách.`,
      response.status,
    );
  }

  return body as T;
}

export async function getDashboardData(token: string): Promise<DashboardData> {
  const [sites, rooms, racks, assets] = await Promise.all([
    getProtected<Site[]>("/sites", token),
    getProtected<Room[]>("/rooms", token),
    getProtected<Rack[]>("/racks", token),
    getProtected<AssetNode[]>("/assets", token),
  ]);

  return { sites, rooms, racks, assets };
}

export function countWorkloads(assets: AssetNode[]): number {
  return assets.reduce((total, asset) => total + (asset.workloads?.length ?? 0), 0);
}
