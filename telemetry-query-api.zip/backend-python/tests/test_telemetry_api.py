import os
import unittest
from datetime import datetime, timedelta, timezone
from types import SimpleNamespace
from unittest.mock import MagicMock, patch
from uuid import uuid4

from flask import Flask

from src.api.controllers.telemetry_controller import (
    create_telemetry_blueprint,
)
from src.domain.constants import Role
from src.domain.exceptions import (
    AuthenticationError,
    ResourceConflictError,
)
from src.domain.models.telemetry import TelemetryRecord
from src.services.telemetry_service import TelemetryService


class TestTelemetryAPI(unittest.TestCase):
    def setUp(self):
        self.agent_key = "test-agent-key"
        self.node_id = str(uuid4())

        self.env = patch.dict(os.environ, {
            "TELEMETRY_AGENT_KEY": self.agent_key,
            "TELEMETRY_AGENT_NODE_IDS": self.node_id,
        })
        self.env.start()
        self.addCleanup(self.env.stop)

        self.telemetry_repo = MagicMock()
        self.server_repo = MagicMock()
        self.server_repo.find_by_id.return_value = SimpleNamespace(
            id=self.node_id
        )

        self.telemetry_service = TelemetryService(
            telemetry_repository=self.telemetry_repo,
            server_repository=self.server_repo,
        )
        self.session_service = MagicMock()
        self.session_service.authenticate_token.side_effect = (
            self._fake_authenticate
        )

        self.app = Flask(__name__)
        self.app.register_blueprint(
            create_telemetry_blueprint(
                telemetry_service=self.telemetry_service,
                session_service=self.session_service,
            )
        )
        self.app.config["TESTING"] = True
        self.client = self.app.test_client()

        self.base_time = datetime(
            2026, 11, 16, 10, 0, 0, tzinfo=timezone.utc
        )
        self.payload = {
            "message_id": str(uuid4()),
            "node_id": self.node_id,
            "measured_at": "2026-11-16T10:00:00+07:00",
            "cpu_percent": 35.5,
            "memory_percent": 60.0,
            "disk_percent": 45.2,
        }

        self.sample_record = TelemetryRecord(
            id=str(uuid4()),
            message_id=self.payload["message_id"],
            node_id=self.node_id,
            measured_at=self.base_time,
            received_at=self.base_time + timedelta(seconds=1),
            cpu_percent=35.5,
            memory_percent=60.0,
            disk_percent=45.2,
        )
        self.telemetry_repo.save.return_value = self.sample_record

    @staticmethod
    def _fake_authenticate(token: str):
        mapping = {
            "admin-token": Role.ADMINISTRATOR,
            "operator-token": Role.OPERATOR,
            "tech-token": Role.TECHNICIAN,
            "unknown-role-token": "Guest",
        }
        if token not in mapping:
            raise AuthenticationError("Token không hợp lệ hoặc đã hết hạn.")
        return SimpleNamespace(
            id=str(uuid4()),
            email="user@arimms.local",
            role=mapping[token],
            is_active=True,
        )

    def _agent_headers(self, key=None):
        return {"X-Agent-Key": self.agent_key if key is None else key}

    @staticmethod
    def _bearer(token="operator-token"):
        return {"Authorization": f"Bearer {token}"}

    # --- Nhóm kiểm thử Ingest (Agent) ---
    def test_01_missing_agent_key(self):
        response = self.client.post("/telemetry", json=self.payload)
        self.assertEqual(response.status_code, 401)

    def test_02_invalid_agent_key(self):
        response = self.client.post(
            "/telemetry",
            json=self.payload,
            headers=self._agent_headers("wrong-key"),
        )
        self.assertEqual(response.status_code, 401)

    def test_03_valid_telemetry_ingest(self):
        response = self.client.post(
            "/telemetry",
            json=self.payload,
            headers=self._agent_headers(),
        )
        self.assertEqual(response.status_code, 200)
        self.assertEqual(
            response.get_json()["message_id"],
            self.payload["message_id"],
        )

    def test_04_conflicting_message_id_returns_409(self):
        self.telemetry_repo.save.side_effect = ResourceConflictError(
            "message_id đã tồn tại với payload khác."
        )
        response = self.client.post(
            "/telemetry",
            json=self.payload,
            headers=self._agent_headers(),
        )
        self.assertEqual(response.status_code, 409)

    # --- Nhóm kiểm thử Auth & RBAC cho Web Portal ---
    def test_05_query_endpoints_require_jwt(self):
        for path in (
            f"/telemetry/nodes/{self.node_id}/latest",
            f"/telemetry/nodes/{self.node_id}/history?start=2026-11-16T09:00:00Z&end=2026-11-16T11:00:00Z",
        ):
            with self.subTest(path=path):
                res_missing = self.client.get(path)
                self.assertEqual(res_missing.status_code, 401)

                res_invalid = self.client.get(
                    path,
                    headers=self._bearer("expired-token"),
                )
                self.assertEqual(res_invalid.status_code, 401)

    def test_06_rbac_roles_allowed_and_forbidden(self):
        self.telemetry_repo.get_latest.return_value = self.sample_record

        for token in ("admin-token", "operator-token", "tech-token"):
            with self.subTest(token=token):
                res = self.client.get(
                    f"/telemetry/nodes/{self.node_id}/latest",
                    headers=self._bearer(token),
                )
                self.assertEqual(res.status_code, 200)

        res_forbidden = self.client.get(
            f"/telemetry/nodes/{self.node_id}/latest",
            headers=self._bearer("unknown-role-token"),
        )
        self.assertEqual(res_forbidden.status_code, 403)

    # --- Nhóm kiểm thử GET /latest ---
    def test_07_get_latest_success_with_units_and_timestamps(self):
        self.telemetry_repo.get_latest.return_value = self.sample_record

        res = self.client.get(
            f"/telemetry/nodes/{self.node_id}/latest",
            headers=self._bearer(),
        )
        self.assertEqual(res.status_code, 200)
        body = res.get_json()
        self.assertEqual(body["node_id"], self.node_id)
        self.assertTrue(body["has_data"])
        self.assertEqual(body["units"]["cpu_percent"], "%")
        self.assertEqual(
            body["telemetry"]["measured_at"],
            self.base_time.isoformat(),
        )
        self.assertEqual(body["telemetry"]["cpu_percent"], 35.5)

    def test_08_get_latest_empty_telemetry_returns_200_null(self):
        self.telemetry_repo.get_latest.return_value = None

        res = self.client.get(
            f"/telemetry/nodes/{self.node_id}/latest",
            headers=self._bearer(),
        )
        self.assertEqual(res.status_code, 200)
        body = res.get_json()
        self.assertEqual(body["node_id"], self.node_id)
        self.assertFalse(body["has_data"])
        self.assertIsNone(body["telemetry"])

    def test_09_get_latest_unknown_node_returns_404(self):
        self.server_repo.find_by_id.return_value = None

        res = self.client.get(
            f"/telemetry/nodes/{uuid4()}/latest",
            headers=self._bearer(),
        )
        self.assertEqual(res.status_code, 404)

    def test_10_invalid_node_uuid_returns_400(self):
        for path in (
            "/telemetry/nodes/invalid-uuid/latest",
            "/telemetry/nodes/invalid-uuid/history?start=2026-11-16T09:00:00Z&end=2026-11-16T11:00:00Z",
        ):
            with self.subTest(path=path):
                res = self.client.get(path, headers=self._bearer())
                self.assertEqual(res.status_code, 400)

    # --- Nhóm kiểm thử GET /history ---
    def test_11_get_history_pagination_and_ordering(self):
        records = [
            TelemetryRecord(
                id=str(uuid4()),
                message_id=str(uuid4()),
                node_id=self.node_id,
                measured_at=self.base_time + timedelta(minutes=i),
                received_at=self.base_time + timedelta(minutes=i, seconds=1),
                cpu_percent=10.0 + i,
                memory_percent=20.0 + i,
                disk_percent=30.0 + i,
            )
            for i in range(3)
        ]
        self.telemetry_repo.list_history.return_value = records

        res = self.client.get(
            f"/telemetry/nodes/{self.node_id}/history",
            query_string={
                "start": "2026-11-16T10:00:00Z",
                "end": "2026-11-16T11:00:00Z",
                "limit": "2",
                "offset": "0",
            },
            headers=self._bearer(),
        )
        self.assertEqual(res.status_code, 200)
        body = res.get_json()
        self.assertEqual(len(body["items"]), 2)
        self.assertTrue(body["pagination"]["has_more"])
        self.assertEqual(body["pagination"]["next_offset"], 2)
        self.assertEqual(body["units"]["memory_percent"], "%")

    def test_12_get_history_empty_range_returns_200_empty_list(self):
        self.telemetry_repo.list_history.return_value = []

        res = self.client.get(
            f"/telemetry/nodes/{self.node_id}/history",
            query_string={
                "start": "2026-11-16T10:00:00Z",
                "end": "2026-11-16T11:00:00Z",
            },
            headers=self._bearer(),
        )
        self.assertEqual(res.status_code, 200)
        body = res.get_json()
        self.assertEqual(body["items"], [])
        self.assertFalse(body["pagination"]["has_more"])
        self.assertIsNone(body["pagination"]["next_offset"])

    def test_13_get_history_invalid_time_or_limits_returns_400(self):
        bad_queries = [
            {"end": "2026-11-16T11:00:00Z"},
            {"start": "2026-11-16T10:00:00"},
            {
                "start": "2026-11-16T11:00:00Z",
                "end": "2026-11-16T10:00:00Z",
            },
            {
                "start": "2026-10-01T00:00:00Z",
                "end": "2026-11-16T00:00:00Z",
            },
            {
                "start": "2026-11-16T10:00:00Z",
                "end": "2026-11-16T11:00:00Z",
                "limit": "1001",
            },
            {
                "start": "2026-11-16T10:00:00Z",
                "end": "2026-11-16T11:00:00Z",
                "limit": "0",
            },
            {
                "start": "2026-11-16T10:00:00Z",
                "end": "2026-11-16T11:00:00Z",
                "offset": "-1",
            },
        ]

        for params in bad_queries:
            with self.subTest(params=params):
                res = self.client.get(
                    f"/telemetry/nodes/{self.node_id}/history",
                    query_string=params,
                    headers=self._bearer(),
                )
                self.assertEqual(res.status_code, 400)


if __name__ == "__main__":
    unittest.main(verbosity=2)
