from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from uuid import UUID

from src.domain.exceptions import (
    ResourceNotFoundError,
    ValidationError,
)
from src.domain.models.telemetry import TelemetryRecord, TelemetrySample
from src.domain.repositories.server_repository import ServerRepository
from src.domain.repositories.telemetry_repository import TelemetryRepository

TELEMETRY_UNITS: dict[str, str] = {
    "cpu_percent": "%",
    "memory_percent": "%",
    "disk_percent": "%",
}


@dataclass(frozen=True, slots=True)
class TelemetryHistoryPage:
    node_id: str
    start: datetime
    end: datetime
    limit: int
    offset: int
    items: list[TelemetryRecord]
    has_more: bool
    next_offset: int | None


class TelemetryService:
    DEFAULT_HISTORY_LIMIT = 100
    MAX_HISTORY_LIMIT = 1000
    MAX_HISTORY_RANGE = timedelta(days=31)

    def __init__(
        self,
        telemetry_repository: TelemetryRepository,
        server_repository: ServerRepository | None = None,
    ):
        self._telemetry_repository = telemetry_repository
        self._server_repository = server_repository

    @staticmethod
    def _validate_node_id(node_id: str) -> str:
        if not isinstance(node_id, str):
            raise ValidationError("node_id phải là UUID hợp lệ.")
        try:
            return str(UUID(node_id))
        except (ValueError, TypeError, AttributeError) as error:
            raise ValidationError(
                "node_id phải là UUID hợp lệ."
            ) from error

    def _ensure_node_exists(self, normalized_node_id: str) -> None:
        if self._server_repository is None:
            return

        node = self._server_repository.find_by_id(normalized_node_id)
        if node is None:
            raise ResourceNotFoundError("Không tìm thấy Node.")

    def ingest(
        self,
        *,
        message_id: str,
        node_id: str,
        measured_at: datetime,
        cpu_percent: float,
        memory_percent: float,
        disk_percent: float,
    ) -> TelemetryRecord:
        sample = TelemetrySample(
            message_id=message_id,
            node_id=node_id,
            measured_at=measured_at,
            cpu_percent=cpu_percent,
            memory_percent=memory_percent,
            disk_percent=disk_percent,
        )

        return self._telemetry_repository.save(sample)

    def get_latest(self, node_id: str) -> tuple[str, TelemetryRecord | None]:
        normalized_id = self._validate_node_id(node_id)
        self._ensure_node_exists(normalized_id)
        record = self._telemetry_repository.get_latest(normalized_id)
        return normalized_id, record

    def get_history(
        self,
        node_id: str,
        *,
        start: datetime,
        end: datetime,
        limit: int = DEFAULT_HISTORY_LIMIT,
        offset: int = 0,
    ) -> TelemetryHistoryPage:
        normalized_id = self._validate_node_id(node_id)

        if (
            not isinstance(start, datetime)
            or start.utcoffset() is None
            or not isinstance(end, datetime)
            or end.utcoffset() is None
        ):
            raise ValidationError(
                "start và end phải là thời điểm ISO-8601 có múi giờ."
            )

        normalized_start = start.astimezone(timezone.utc)
        normalized_end = end.astimezone(timezone.utc)

        if normalized_start >= normalized_end:
            raise ValidationError("start phải nhỏ hơn end.")

        if normalized_end - normalized_start > self.MAX_HISTORY_RANGE:
            raise ValidationError(
                "Khoảng thời gian truy vấn không được vượt quá 31 ngày."
            )

        if (
            type(limit) is not int
            or not 1 <= limit <= self.MAX_HISTORY_LIMIT
        ):
            raise ValidationError(
                f"limit phải là số nguyên từ 1 đến {self.MAX_HISTORY_LIMIT}."
            )

        if type(offset) is not int or offset < 0:
            raise ValidationError(
                "offset phải là số nguyên lớn hơn hoặc bằng 0."
            )

        self._ensure_node_exists(normalized_id)

        rows = self._telemetry_repository.list_history(
            normalized_id,
            start=normalized_start,
            end=normalized_end,
            limit=limit + 1,
            offset=offset,
        )

        has_more = len(rows) > limit
        items = rows[:limit]
        next_offset = offset + len(items) if has_more else None

        return TelemetryHistoryPage(
            node_id=normalized_id,
            start=normalized_start,
            end=normalized_end,
            limit=limit,
            offset=offset,
            items=items,
            has_more=has_more,
            next_offset=next_offset,
        )
