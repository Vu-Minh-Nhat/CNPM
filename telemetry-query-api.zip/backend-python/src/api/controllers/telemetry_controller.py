import hmac
import os
from datetime import datetime, timezone
from math import isfinite

from flask import Blueprint, jsonify, request
from sqlalchemy.exc import SQLAlchemyError

from src.api.middleware import require_auth
from src.domain.constants import Role
from src.domain.exceptions import (
    ResourceConflictError,
    ResourceNotFoundError,
    ValidationError,
)
from src.domain.models.telemetry import TelemetryRecord
from src.services.session_service import SessionService
from src.services.telemetry_service import (
    TELEMETRY_UNITS,
    TelemetryService,
)

WEB_TELEMETRY_ROLES = (
    Role.ADMINISTRATOR,
    Role.OPERATOR,
    Role.TECHNICIAN,
)


def _serialize_record(record: TelemetryRecord) -> dict:
    return {
        "id": str(record.id),
        "message_id": str(record.message_id),
        "node_id": str(record.node_id),
        "measured_at": record.measured_at.isoformat(),
        "received_at": record.received_at.isoformat(),
        "cpu_percent": record.cpu_percent,
        "memory_percent": record.memory_percent,
        "disk_percent": record.disk_percent,
    }


def _parse_iso_datetime(raw_value: str | None, field_name: str) -> datetime:
    if not raw_value or not raw_value.strip():
        raise ValidationError(f"Thiếu tham số bắt buộc: {field_name}.")

    text = raw_value.strip()
    if "T" not in text and "t" not in text:
        raise ValidationError(
            f"{field_name} phải theo định dạng ISO-8601 có giờ và múi giờ."
        )

    try:
        parsed = datetime.fromisoformat(text.replace("Z", "+00:00"))
    except ValueError as error:
        raise ValidationError(
            f"{field_name} không đúng định dạng thời gian ISO-8601."
        ) from error

    if parsed.tzinfo is None or parsed.utcoffset() is None:
        raise ValidationError(f"{field_name} phải có thông tin múi giờ.")

    return parsed


def _parse_int_query(
    raw_value: str | None,
    field_name: str,
    default: int,
) -> int:
    if raw_value is None or raw_value == "":
        return default

    text = raw_value.strip()
    if text.lower() in {"true", "false"}:
        raise ValidationError(f"{field_name} phải là số nguyên hợp lệ.")

    try:
        return int(text)
    except ValueError as error:
        raise ValidationError(
            f"{field_name} phải là số nguyên hợp lệ."
        ) from error


def create_telemetry_blueprint(
    telemetry_service: TelemetryService,
    session_service: SessionService,
):
    blueprint = Blueprint("telemetry", __name__, url_prefix="/telemetry")

    @blueprint.post("")
    def ingest_telemetry():
        # 1. Authenticate Agent
        configured_key = os.getenv("TELEMETRY_AGENT_KEY", "").strip()
        provided_key = request.headers.get("X-Agent-Key", "")

        if not configured_key:
            return jsonify({
                "message": "Server chua cau hinh Agent API key.",
                "error": "ServiceUnavailable",
                "statusCode": 503,
            }), 503

        if not provided_key or not hmac.compare_digest(
            provided_key, configured_key
        ):
            return jsonify({
                "message": "Agent API key khong hop le.",
                "error": "Unauthorized",
                "statusCode": 401,
            }), 401

        # 2. Validate request body
        data = request.get_json(silent=True)

        if not isinstance(data, dict):
            return jsonify({
                "message": "Du lieu telemetry khong hop le.",
                "error": "BadRequest",
                "statusCode": 400,
            }), 400

        required_fields = [
            "message_id",
            "node_id",
            "measured_at",
            "cpu_percent",
            "memory_percent",
            "disk_percent",
        ]

        missing_fields = [
            field for field in required_fields if field not in data
        ]

        if missing_fields:
            return jsonify({
                "message": "Thieu truong bat buoc.",
                "missingFields": missing_fields,
                "error": "BadRequest",
                "statusCode": 400,
            }), 400

        # 3. Check Agent permission for Node
        allowed_node_ids = {
            item.strip()
            for item in os.getenv(
                "TELEMETRY_AGENT_NODE_IDS", ""
            ).split(",")
            if item.strip()
        }

        node_id = str(data["node_id"])

        if node_id not in allowed_node_ids:
            return jsonify({
                "message": "Agent khong co quyen gui du lieu cho Node nay.",
                "error": "Forbidden",
                "statusCode": 403,
            }), 403

        # 4. Validate timestamp and metric values
        try:
            measured_at = datetime.fromisoformat(
                str(data["measured_at"]).replace("Z", "+00:00")
            )

            if measured_at.tzinfo is None:
                raise ValueError("Timestamp phai co mui gio.")

            percentages = {}

            for field in (
                "cpu_percent",
                "memory_percent",
                "disk_percent",
            ):
                value = data[field]

                if isinstance(value, bool):
                    raise ValueError(f"{field} khong hop le.")

                value = float(value)

                if not isfinite(value) or not 0 <= value <= 100:
                    raise ValueError(
                        f"{field} phai nam trong khoang 0 den 100."
                    )

                percentages[field] = value

        except (TypeError, ValueError, OverflowError):
            return jsonify({
                "message": "Timestamp hoac gia tri telemetry khong hop le.",
                "error": "BadRequest",
                "statusCode": 400,
            }), 400

        # 5. Save telemetry
        try:
            record = telemetry_service.ingest(
                message_id=str(data["message_id"]),
                node_id=node_id,
                measured_at=measured_at.astimezone(timezone.utc),
                cpu_percent=percentages["cpu_percent"],
                memory_percent=percentages["memory_percent"],
                disk_percent=percentages["disk_percent"],
            )

        except ResourceConflictError as exc:
            return jsonify({
                "message": str(exc),
                "error": "Conflict",
                "statusCode": 409,
            }), 409

        except ValidationError as exc:
            return jsonify({
                "message": str(exc),
                "error": "BadRequest",
                "statusCode": 400,
            }), 400

        except ResourceNotFoundError as exc:
            return jsonify({
                "message": str(exc),
                "error": "NotFound",
                "statusCode": 404,
            }), 404

        except SQLAlchemyError:
            return jsonify({
                "message": "Database tam thoi khong kha dung.",
                "error": "ServiceUnavailable",
                "statusCode": 503,
            }), 503

        except Exception:
            return jsonify({
                "message": "Loi he thong khi xu ly telemetry.",
                "error": "InternalServerError",
                "statusCode": 500,
            }), 500

        # 6. Return saved record
        return jsonify(_serialize_record(record)), 200

    @blueprint.get("/nodes/<node_id>/latest")
    @require_auth(
        session_service=session_service,
        allowed_roles=WEB_TELEMETRY_ROLES,
    )
    def get_latest_telemetry(node_id: str):
        try:
            normalized_id, record = telemetry_service.get_latest(node_id)
        except ValidationError as exc:
            return jsonify({
                "message": str(exc),
                "error": "Bad Request",
                "statusCode": 400,
            }), 400
        except ResourceNotFoundError as exc:
            return jsonify({
                "message": str(exc),
                "error": "Not Found",
                "statusCode": 404,
            }), 404
        except SQLAlchemyError:
            return jsonify({
                "message": "Database tạm thời không khả dụng.",
                "error": "Service Unavailable",
                "statusCode": 503,
            }), 503

        return jsonify({
            "node_id": normalized_id,
            "latest_rule": "measured_at DESC, received_at DESC, id DESC",
            "has_data": record is not None,
            "units": TELEMETRY_UNITS,
            "telemetry": _serialize_record(record) if record else None,
        }), 200

    @blueprint.get("/nodes/<node_id>/history")
    @require_auth(
        session_service=session_service,
        allowed_roles=WEB_TELEMETRY_ROLES,
    )
    def get_telemetry_history(node_id: str):
        try:
            start = _parse_iso_datetime(request.args.get("start"), "start")
            end = _parse_iso_datetime(request.args.get("end"), "end")
            limit = _parse_int_query(
                request.args.get("limit"),
                "limit",
                TelemetryService.DEFAULT_HISTORY_LIMIT,
            )
            offset = _parse_int_query(
                request.args.get("offset"),
                "offset",
                0,
            )

            page = telemetry_service.get_history(
                node_id,
                start=start,
                end=end,
                limit=limit,
                offset=offset,
            )
        except ValidationError as exc:
            return jsonify({
                "message": str(exc),
                "error": "Bad Request",
                "statusCode": 400,
            }), 400
        except ResourceNotFoundError as exc:
            return jsonify({
                "message": str(exc),
                "error": "Not Found",
                "statusCode": 404,
            }), 404
        except SQLAlchemyError:
            return jsonify({
                "message": "Database tạm thời không khả dụng.",
                "error": "Service Unavailable",
                "statusCode": 503,
            }), 503

        return jsonify({
            "node_id": page.node_id,
            "range": {
                "start": page.start.isoformat(),
                "end": page.end.isoformat(),
                "inclusive_start": True,
                "exclusive_end": True,
            },
            "order": "measured_at ASC, received_at ASC, id ASC",
            "units": TELEMETRY_UNITS,
            "pagination": {
                "limit": page.limit,
                "offset": page.offset,
                "count": len(page.items),
                "has_more": page.has_more,
                "next_offset": page.next_offset,
            },
            "items": [_serialize_record(item) for item in page.items],
        }), 200

    return blueprint
