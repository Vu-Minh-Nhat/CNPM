# Hợp đồng API Truy vấn Telemetry (Latest & History)

## 1. Quy ước nghiệp vụ & Phạm vi

- **Dữ liệu mới nhất (`latest`):** Sắp xếp giảm dần theo `measured_at DESC, received_at DESC, id DESC`.
- **Dữ liệu lịch sử (`history`):** Truy vấn theo nửa khoảng `[start, end)` (`start <= measured_at < end`), sắp xếp tăng dần theo `measured_at ASC, received_at ASC, id ASC`. Khoảng thời gian tối đa mỗi lần truy vấn là **31 ngày**.
- **Giới hạn & Phân trang:** Tham số `limit` mặc định `100` (cho phép `1..1000`), `offset` mặc định `0` (`>= 0`). Phản hồi trả về metadata `pagination` (`limit`, `offset`, `count`, `has_more`, `next_offset`).
- **Xử lý Node chưa có dữ liệu:** Nếu `node_id` tồn tại trong hệ thống nhưng chưa có bản ghi telemetry, API trả về HTTP `200` với `has_data: false, telemetry: null` (hoặc `items: []` với lịch sử) — không trả lỗi `500` và không gán giá trị giả định bằng `0`. Nếu `node_id` không tồn tại, trả về `404 Not Found`.
- **Xác thực & Phân quyền:** Yêu cầu `Authorization: Bearer <JWT>` của một trong ba vai trò `Administrator`, `Operator`, `Technician`.

## 2. Danh sách Endpoint

| Method | Endpoint | Chức năng | Quyền truy cập |
| --- | --- | --- | --- |
| `POST` | `/telemetry` | Collector Agent gửi mẫu telemetry | `X-Agent-Key` |
| `GET` | `/telemetry/nodes/:node_id/latest` | Lấy mẫu telemetry mới nhất của Node | `Bearer JWT` (`Administrator`, `Operator`, `Technician`) |
| `GET` | `/telemetry/nodes/:node_id/history` | Truy vấn lịch sử telemetry của Node theo khoảng thời gian | `Bearer JWT` (`Administrator`, `Operator`, `Technician`) |

## 3. Chi tiết Request & Response

### 3.1. `GET /telemetry/nodes/:node_id/latest`

```http
GET /telemetry/nodes/44444444-4444-4444-8444-444444444444/latest
Authorization: Bearer YOUR_ACCESS_TOKEN
```

**Response `200 OK` (khi Node có dữ liệu):**

```json
{
  "node_id": "44444444-4444-4444-8444-444444444444",
  "latest_rule": "measured_at DESC, received_at DESC, id DESC",
  "has_data": true,
  "units": {
    "cpu_percent": "%",
    "memory_percent": "%",
    "disk_percent": "%"
  },
  "telemetry": {
    "id": "9a1c8c72-6a4b-4e1a-9f11-111111111111",
    "message_id": "2c8f41c0-9d2a-4b11-8a22-222222222222",
    "node_id": "44444444-4444-4444-8444-444444444444",
    "measured_at": "2026-11-16T13:00:05+00:00",
    "received_at": "2026-11-16T13:00:06+00:00",
    "cpu_percent": 35.5,
    "memory_percent": 60.0,
    "disk_percent": 45.2
  }
}
```

**Response `200 OK` (khi Node tồn tại nhưng chưa có telemetry):**

```json
{
  "node_id": "44444444-4444-4444-8444-444444444444",
  "latest_rule": "measured_at DESC, received_at DESC, id DESC",
  "has_data": false,
  "units": {
    "cpu_percent": "%",
    "memory_percent": "%",
    "disk_percent": "%"
  },
  "telemetry": null
}
```

### 3.2. `GET /telemetry/nodes/:node_id/history`

```http
GET /telemetry/nodes/44444444-4444-4444-8444-444444444444/history?start=2026-11-16T12:00:00Z&end=2026-11-16T13:00:00Z&limit=100&offset=0
Authorization: Bearer YOUR_ACCESS_TOKEN
```

**Response `200 OK`:**

```json
{
  "node_id": "44444444-4444-4444-8444-444444444444",
  "range": {
    "start": "2026-11-16T12:00:00+00:00",
    "end": "2026-11-16T13:00:00+00:00",
    "inclusive_start": true,
    "exclusive_end": true
  },
  "order": "measured_at ASC, received_at ASC, id ASC",
  "units": {
    "cpu_percent": "%",
    "memory_percent": "%",
    "disk_percent": "%"
  },
  "pagination": {
    "limit": 100,
    "offset": 0,
    "count": 1,
    "has_more": false,
    "next_offset": null
  },
  "items": [
    {
      "id": "9a1c8c72-6a4b-4e1a-9f11-111111111111",
      "message_id": "2c8f41c0-9d2a-4b11-8a22-222222222222",
      "node_id": "44444444-4444-4444-8444-444444444444",
      "measured_at": "2026-11-16T12:05:00+00:00",
      "received_at": "2026-11-16T12:05:01+00:00",
      "cpu_percent": 31.2,
      "memory_percent": 58.4,
      "disk_percent": 45.0
    }
  ]
}
```

## 4. Mã trạng thái lỗi

| Mã HTTP | Nguyên nhân |
| --- | --- |
| `400` | `node_id` sai định dạng UUID; thiếu `start`/`end`; timestamp thiếu múi giờ; `start >= end`; khoảng thời gian vượt 31 ngày; `limit`/`offset` ngoài phạm vi hợp lệ |
| `401` | Thiếu JWT, JWT không hợp lệ hoặc đã hết hạn |
| `403` | Tài khoản đã xác thực nhưng vai trò không nằm trong danh sách được cấp quyền |
| `404` | Không tìm thấy Node tương ứng với `node_id` |
| `503` | Database tạm thời không khả dụng |

## 5. Hướng dẫn kiểm thử tự động

Chạy bộ test từ thư mục `backend-python`:

```powershell
& ".\.venv\Scripts\python.exe" -m unittest discover -s tests -p "test_telemetry_api.py" -v
```
