import 'dotenv/config';
import { INestApplication } from '@nestjs/common';
import { Test } from '@nestjs/testing';
import request from 'supertest';
import { AppModule } from '../src/app.module.js';
describe('RBAC (e2e)', () => {
  let app: INestApplication;
  let adminToken = '';
  let operatorToken = '';
  let technicianToken = '';
  const suffix = `${Date.now()}`;
  const email = (role: string) => `rbac-${role}-${suffix}@example.test`;
  const password = 'TestPassword@12345';
  const login = async (userEmail: string, userPassword: string) => {
    const response = await request(app.getHttpServer()).post('/api/v1/auth/login').send({ email: userEmail, password: userPassword }).expect(200);
    return response.body.accessToken as string;
  };
  beforeAll(async () => {
    const moduleRef = await Test.createTestingModule({ imports: [AppModule] }).compile();
    app = moduleRef.createNestApplication(); app.setGlobalPrefix('api/v1'); await app.init();
    const adminEmail = process.env.SEED_ADMIN_EMAIL ?? 'admin@arimms.local';
    const adminPassword = process.env.SEED_ADMIN_PASSWORD;
    if (!adminPassword) throw new Error('Set SEED_ADMIN_PASSWORD in .env and run npm run seed before e2e tests.');
    adminToken = await login(adminEmail, adminPassword);
    await request(app.getHttpServer()).post('/api/v1/users').set('Authorization', `Bearer ${adminToken}`).send({ email: email('operator'), password, role: 'Operator' }).expect(201);
    await request(app.getHttpServer()).post('/api/v1/users').set('Authorization', `Bearer ${adminToken}`).send({ email: email('technician'), password, role: 'Technician' }).expect(201);
    operatorToken = await login(email('operator'), password);
    technicianToken = await login(email('technician'), password);
  });
  afterAll(async () => { await app?.close(); });
  it('rejects requests without a token', () => request(app.getHttpServer()).get('/api/v1/users').expect(401));
  it('rejects an invalid token', () => request(app.getHttpServer()).get('/api/v1/users').set('Authorization', 'Bearer invalid.token').expect(401));
  it('allows Administrator to list users', () => request(app.getHttpServer()).get('/api/v1/users').set('Authorization', `Bearer ${adminToken}`).expect(200));
  it('denies Operator access to user administration', () => request(app.getHttpServer()).get('/api/v1/users').set('Authorization', `Bearer ${operatorToken}`).expect(403));
  it('denies Technician access to user administration', () => request(app.getHttpServer()).get('/api/v1/users').set('Authorization', `Bearer ${technicianToken}`).expect(403));
  it('allows Technician to read assets', () => request(app.getHttpServer()).get('/api/v1/assets').set('Authorization', `Bearer ${technicianToken}`).expect(200));
});
