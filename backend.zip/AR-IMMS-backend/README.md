# AR-IMMS Backend (NestJS)

Backend starter for the Automated Remote Infrastructure Monitoring and Management System. Includes JWT authentication, RBAC, users, sites, assets and asset hierarchy, telemetry ingestion, stale/duplicate detection, alerts, maintenance requests, audit logs and ingestion-error tracking.

## 1. Requirements
- Node.js 20+ (tested with Node 22)
- PostgreSQL 14+
- npm

## 2. Configure
```powershell
Copy-Item .env.example .env
```
Edit `.env` and set `DB_HOST`, `DB_PORT`, `DB_USERNAME`, `DB_PASSWORD`, `DB_DATABASE`, `JWT_SECRET`, and `SEED_ADMIN_PASSWORD`. Use a long random `JWT_SECRET` and an admin password of at least 12 characters. Create the PostgreSQL database named in `DB_DATABASE` first.

Install dependencies:
```powershell
npm install
```

For development, TypeORM synchronizes the entity schema automatically (`NODE_ENV=development`). Do not enable `synchronize` in production; use a reviewed migration/schema deployment instead.

Create the first administrator:
```powershell
npm run seed
```
The seed command is idempotent: it will not overwrite an existing admin account.

## 3. Run and verify
```powershell
npm run start:dev
```
Base API URL: `http://localhost:3000/api/v1`
- `GET /health` is public.
- `POST /auth/login` is public.
- All other endpoints require `Authorization: Bearer <accessToken>` and explicit role metadata.

Build:
```powershell
npm run build
```

## 4. RBAC policy
| Role | Access summary |
|---|---|
| Administrator | Full user/role management; create/update/delete sites and assets; read audit logs and ingestion errors; monitoring and maintenance APIs |
| Operator | Read sites/assets/telemetry/alerts/maintenance; create/update sites/assets; ingest telemetry; manage alert status and maintenance; review ingestion errors |
| Technician | Read monitoring data; update alert status; create/update maintenance requests; no user, site, or asset administration |

RBAC is enforced by global `JwtAuthGuard` + `RolesGuard`, with `@Public()` only for intentionally public routes. User roles are loaded from the database on each request so role changes and account deactivation take effect immediately.

## 5. API overview
All paths below are prefixed with `/api/v1`.

| Method | Endpoint | Roles |
|---|---|---|
| GET | `/health` | Public |
| POST | `/auth/login` | Public |
| GET | `/auth/me` | All authenticated roles |
| GET, POST | `/users` | Administrator |
| PATCH | `/users/:id/role` | Administrator |
| PATCH | `/users/:id/status` | Administrator |
| GET, GET `/:id`, POST, PATCH `/:id`, DELETE `/:id` | `/sites` | Read: all; write: Administrator/Operator; delete: Administrator |
| GET, GET `/:id`, POST, PATCH `/:id`, DELETE `/:id` | `/assets` | Read: all; write: Administrator/Operator; delete: Administrator |
| POST, GET | `/telemetry` | Ingest: Administrator/Operator; read: all |
| GET, PATCH `/:id/status` | `/alerts` | Read: all; update status: all roles |
| GET, POST, PATCH `/:id` | `/maintenance` | All authenticated roles (within role policy above) |
| GET | `/audit-logs` | Administrator |
| GET, PATCH `/:id/resolve` | `/ingestion-errors` | Administrator/Operator |

### Login example
```json
{
  "email": "admin@arimms.local",
  "password": "the-password-you-configured-in-.env"
}
```
Response contains `accessToken`, `tokenType`, `expiresIn`, and the user's public profile.

### Telemetry payload example
```json
{
  "assetId": "<existing-asset-uuid>",
  "sourceId": "gateway-01",
  "externalId": "event-000001",
  "metric": "temperature",
  "value": 31.4,
  "unit": "C",
  "recordedAt": "2026-10-29T12:00:00.000Z"
}
```
`sourceId + externalId` is the idempotency key. Duplicate events are rejected and recorded in `ingestion_errors`. Records older than `TELEMETRY_STALE_AFTER_MINUTES` are stored with `isStale=true` and create a stale-telemetry alert. Invalid asset references are also logged as ingestion errors.

## 6. Important implementation notes
- The project uses PostgreSQL and TypeORM. Development schema synchronization is enabled only outside production.
- A proper production deployment still needs versioned migrations, secrets management, backups, rate limiting, and environment-specific integration tests.
- The alert implementation currently detects stale telemetry. Metric-specific high/low thresholds must be defined from the project's actual requirements before automatic threshold alerts can be implemented accurately.
- For multi-source integrations, add provider-specific adapters and retry/backoff at the ingestion boundary. The current API provides idempotency, bounded exponential retry for telemetry persistence, and error tracking. Provider-specific polling/adapters for external vendor systems still need to be added for each integration source.
