import 'dotenv/config';
import { Module } from '@nestjs/common';
import { APP_GUARD } from '@nestjs/core';
import { ConfigModule } from '@nestjs/config';
import { TypeOrmModule } from '@nestjs/typeorm';
import { AuthModule } from './auth/auth.module.js';
import { JwtAuthGuard } from './auth/jwt-auth.guard.js';
import { RolesGuard } from './auth/roles.guard.js';
import { AuditModule } from './audit/audit.module.js';
import { AlertsModule } from './alerts/alerts.module.js';
import { AssetsModule } from './assets/assets.module.js';
import { AuditSharedModule } from './common/audit.module.js';
import { APP_ENTITIES } from './database/database.module.js';
import { HealthModule } from './health/health.module.js';
import { IngestionModule } from './ingestion/ingestion.module.js';
import { MaintenanceModule } from './maintenance/maintenance.module.js';
import { SitesModule } from './sites/sites.module.js';
import { TelemetryModule } from './telemetry/telemetry.module.js';
import { UsersModule } from './users/users.module.js';
import { AppController } from './app.controller.js';

@Module({
  imports: [
    ConfigModule.forRoot({ isGlobal: true }),
    TypeOrmModule.forRoot({
      type: 'postgres', host: process.env.DB_HOST ?? 'localhost', port: Number(process.env.DB_PORT ?? 5432),
      username: process.env.DB_USERNAME ?? 'postgres', password: process.env.DB_PASSWORD ?? 'postgres', database: process.env.DB_DATABASE ?? 'ar_imms',
      ssl: process.env.DB_SSL === 'true' ? { rejectUnauthorized: false } : false,
      entities: APP_ENTITIES, synchronize: process.env.NODE_ENV !== 'production', autoLoadEntities: true,
      retryAttempts: 5, retryDelay: 3000,
    }),
    AuthModule, UsersModule, AssetsModule, SitesModule, TelemetryModule, AuditModule, AuditSharedModule,
    AlertsModule, MaintenanceModule, IngestionModule, HealthModule,
  ],
  controllers: [AppController],
  providers: [
    { provide: APP_GUARD, useClass: JwtAuthGuard },
    { provide: APP_GUARD, useClass: RolesGuard },
  ],
})
export class AppModule {}

