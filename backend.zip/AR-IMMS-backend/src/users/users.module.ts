import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { AuditSharedModule } from '../common/audit.module.js';
import { UserEntity } from '../database/entities.js';
import { UsersController } from './users.controller.js';
import { UsersService } from './users.service.js';
@Module({ imports: [TypeOrmModule.forFeature([UserEntity]), AuditSharedModule], controllers: [UsersController], providers: [UsersService], exports: [UsersService] })
export class UsersModule {}
