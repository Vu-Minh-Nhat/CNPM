import { Body, Controller, Get, Param, Patch, Post, Req, UsePipes, ValidationPipe } from '@nestjs/common';
import { IsBoolean, IsEmail, IsEnum, IsOptional, IsString, MinLength } from 'class-validator';
import { Roles } from '../common/decorators/roles.decorator.js';
import { Role } from '../common/enums/role.enum.js';
import { AuditService } from '../common/audit.service.js';
import type { CurrentUser } from '../common/current-user.js';
import { UsersService } from './users.service.js';
class CreateUserDto { @IsEmail() email!: string; @IsString() @MinLength(8) password!: string; @IsEnum(Role) role!: Role; }
class ChangeRoleDto { @IsEnum(Role) role!: Role; }
class ActiveDto { @IsBoolean() isActive!: boolean; }
@Controller('users')
@Roles(Role.ADMINISTRATOR)
@UsePipes(new ValidationPipe({ whitelist: true, forbidNonWhitelisted: true, transform: true }))
export class UsersController {
  constructor(private readonly users: UsersService, private readonly audit: AuditService) {}
  @Get() list() { return this.users.list(); }
  @Post() async create(@Body() body: CreateUserDto, @Req() req: any) {
    const user = await this.users.create(body.email, body.password, body.role);
    await this.audit.record(req.user as CurrentUser, 'CREATE', 'user', user.id, { email: user.email, role: user.role }, req.ip);
    const { passwordHash: _secret, ...safe } = user as any; return safe;
  }
  @Patch(':id/role') async changeRole(@Param('id') id: string, @Body() body: ChangeRoleDto, @Req() req: any) {
    const user = await this.users.changeRole(id, body.role);
    await this.audit.record(req.user as CurrentUser, 'CHANGE_ROLE', 'user', id, { role: body.role }, req.ip);
    return user;
  }
  @Patch(':id/status') async setActive(@Param('id') id: string, @Body() body: ActiveDto, @Req() req: any) {
    const user = await this.users.setActive(id, body.isActive);
    await this.audit.record(req.user as CurrentUser, 'CHANGE_STATUS', 'user', id, { isActive: body.isActive }, req.ip);
    return user;
  }
}
