import { ConflictException, Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import * as bcrypt from 'bcryptjs';
import { Repository } from 'typeorm';
import { Role } from '../common/enums/role.enum.js';
import { UserEntity } from '../database/entities.js';

@Injectable()
export class UsersService {
  constructor(@InjectRepository(UserEntity) private readonly repo: Repository<UserEntity>) {}
  async findByEmail(email: string, includePassword = false) {
    const query = this.repo.createQueryBuilder('user').where('LOWER(user.email) = LOWER(:email)', { email });
    if (includePassword) query.addSelect('user.passwordHash');
    return query.getOne();
  }
  findById(id: string) { return this.repo.findOne({ where: { id } }); }
  async list() { return this.repo.find({ order: { createdAt: 'DESC' } }); }
  async create(email: string, password: string, role: Role) {
    if (await this.findByEmail(email)) throw new ConflictException('Email đã tồn tại');
    const user = this.repo.create({ email: email.trim().toLowerCase(), passwordHash: await bcrypt.hash(password, 12), role, isActive: true });
    return this.repo.save(user);
  }
  async changeRole(id: string, role: Role) {
    const user = await this.findById(id);
    if (!user) throw new NotFoundException('Không tìm thấy tài khoản');
    user.role = role;
    return this.repo.save(user);
  }
  async setActive(id: string, isActive: boolean) {
    const user = await this.findById(id);
    if (!user) throw new NotFoundException('Không tìm thấy tài khoản');
    user.isActive = isActive;
    return this.repo.save(user);
  }
}
