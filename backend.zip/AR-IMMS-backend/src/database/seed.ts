import 'reflect-metadata';
import 'dotenv/config';
import * as bcrypt from 'bcryptjs';
import { AppDataSource } from './data-source.js';
import { UserEntity } from './entities.js';
import { Role } from '../common/enums/role.enum.js';
async function seed() {
  await AppDataSource.initialize();
  try {
    const repo = AppDataSource.getRepository(UserEntity);
    const email = (process.env.SEED_ADMIN_EMAIL ?? 'admin@arimms.local').toLowerCase();
    const password = process.env.SEED_ADMIN_PASSWORD;
    if (!password || password.length < 12) throw new Error('Hãy đặt SEED_ADMIN_PASSWORD tối thiểu 12 ký tự trong .env trước khi seed.');
    const existing = await repo.findOne({ where: { email } });
    if (existing) { console.log(`Admin ${email} đã tồn tại; không thay đổi tài khoản.`); return; }
    await repo.save(repo.create({ email, passwordHash: await bcrypt.hash(password, 12), role: Role.ADMINISTRATOR, isActive: true }));
    console.log(`Đã tạo tài khoản Administrator: ${email}`);
  } finally { await AppDataSource.destroy(); }
}
seed().catch((error) => { console.error(error); process.exitCode = 1; });
