import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { UserEntity, SiteEntity, AssetEntity, TelemetryEntity, AlertEntity, MaintenanceEntity, AuditLogEntity, IngestionErrorEntity } from './entities.js';
export const APP_ENTITIES = [UserEntity, SiteEntity, AssetEntity, TelemetryEntity, AlertEntity, MaintenanceEntity, AuditLogEntity, IngestionErrorEntity];
@Module({ imports: [TypeOrmModule.forFeature(APP_ENTITIES)], exports: [TypeOrmModule] })
export class DatabaseModule {}
