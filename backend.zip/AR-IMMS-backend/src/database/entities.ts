import { Column, CreateDateColumn, Entity, Index, PrimaryGeneratedColumn, UpdateDateColumn } from 'typeorm';
import { Role } from '../common/enums/role.enum.js';

@Entity('users')
@Index(['email'], { unique: true })
export class UserEntity {
  @PrimaryGeneratedColumn('uuid') id!: string;
  @Column({ length: 254 }) email!: string;
  @Column({ name: 'password_hash', select: false }) passwordHash!: string;
  @Column({ type: 'enum', enum: Role, default: Role.TECHNICIAN }) role!: Role;
  @Column({ name: 'is_active', default: true }) isActive!: boolean;
  @CreateDateColumn({ name: 'created_at', type: 'timestamptz' }) createdAt!: Date;
  @UpdateDateColumn({ name: 'updated_at', type: 'timestamptz' }) updatedAt!: Date;
}

@Entity('sites')
@Index(['code'], { unique: true })
export class SiteEntity {
  @PrimaryGeneratedColumn('uuid') id!: string;
  @Column({ length: 80 }) code!: string;
  @Column({ length: 160 }) name!: string;
  @Column({ type: 'text', nullable: true }) address!: string | null;
  @Column({ type: 'text', nullable: true }) description!: string | null;
  @Column({ default: true }) isActive!: boolean;
  @CreateDateColumn({ name: 'created_at', type: 'timestamptz' }) createdAt!: Date;
  @UpdateDateColumn({ name: 'updated_at', type: 'timestamptz' }) updatedAt!: Date;
}

@Entity('assets')
@Index(['code'], { unique: true })
export class AssetEntity {
  @PrimaryGeneratedColumn('uuid') id!: string;
  @Column({ length: 80 }) code!: string;
  @Column({ length: 160 }) name!: string;
  @Column({ length: 100 }) type!: string;
  @Column({ name: 'site_id', type: 'uuid' }) siteId!: string;
  @Column({ name: 'parent_asset_id', type: 'uuid', nullable: true }) parentAssetId!: string | null;
  @Column({ type: 'text', nullable: true }) description!: string | null;
  @Column({ default: 'active' }) status!: string;
  @CreateDateColumn({ name: 'created_at', type: 'timestamptz' }) createdAt!: Date;
  @UpdateDateColumn({ name: 'updated_at', type: 'timestamptz' }) updatedAt!: Date;
}

@Entity('telemetry')
@Index(['sourceId', 'externalId'], { unique: true })
@Index(['assetId', 'recordedAt'])
export class TelemetryEntity {
  @PrimaryGeneratedColumn('uuid') id!: string;
  @Column({ name: 'asset_id', type: 'uuid' }) assetId!: string;
  @Column({ name: 'source_id', length: 100 }) sourceId!: string;
  @Column({ name: 'external_id', length: 160 }) externalId!: string;
  @Column({ length: 100 }) metric!: string;
  @Column({ type: 'double precision' }) value!: number;
  @Column({ length: 40, nullable: true }) unit!: string | null;
  @Column({ name: 'recorded_at', type: 'timestamptz' }) recordedAt!: Date;
  @CreateDateColumn({ name: 'received_at', type: 'timestamptz' }) receivedAt!: Date;
  @Column({ name: 'is_stale', default: false }) isStale!: boolean;
}

@Entity('alerts')
export class AlertEntity {
  @PrimaryGeneratedColumn('uuid') id!: string;
  @Column({ name: 'asset_id', type: 'uuid' }) assetId!: string;
  @Column({ length: 100 }) type!: string;
  @Column({ length: 20, default: 'medium' }) severity!: string;
  @Column({ length: 240 }) message!: string;
  @Column({ length: 20, default: 'open' }) status!: string;
  @Column({ name: 'triggered_at', type: 'timestamptz', default: () => 'CURRENT_TIMESTAMP' }) triggeredAt!: Date;
  @Column({ name: 'resolved_at', type: 'timestamptz', nullable: true }) resolvedAt!: Date | null;
  @Column({ name: 'resolved_by', type: 'uuid', nullable: true }) resolvedBy!: string | null;
}

@Entity('maintenance_requests')
export class MaintenanceEntity {
  @PrimaryGeneratedColumn('uuid') id!: string;
  @Column({ name: 'asset_id', type: 'uuid' }) assetId!: string;
  @Column({ length: 200 }) title!: string;
  @Column({ type: 'text' }) description!: string;
  @Column({ length: 20, default: 'open' }) status!: string;
  @Column({ length: 20, default: 'normal' }) priority!: string;
  @Column({ name: 'assigned_to', type: 'uuid', nullable: true }) assignedTo!: string | null;
  @Column({ name: 'created_by', type: 'uuid' }) createdBy!: string;
  @Column({ name: 'due_at', type: 'timestamptz', nullable: true }) dueAt!: Date | null;
  @CreateDateColumn({ name: 'created_at', type: 'timestamptz' }) createdAt!: Date;
  @UpdateDateColumn({ name: 'updated_at', type: 'timestamptz' }) updatedAt!: Date;
}

@Entity('audit_logs')
@Index(['createdAt'])
export class AuditLogEntity {
  @PrimaryGeneratedColumn('uuid') id!: string;
  @Column({ name: 'actor_id', type: 'uuid', nullable: true }) actorId!: string | null;
  @Column({ name: 'actor_email', length: 254, nullable: true }) actorEmail!: string | null;
  @Column({ length: 100 }) action!: string;
  @Column({ length: 100 }) resource!: string;
  @Column({ name: 'resource_id', length: 100, nullable: true }) resourceId!: string | null;
  @Column({ type: 'jsonb', nullable: true }) details!: Record<string, unknown> | null;
  @Column({ name: 'ip_address', length: 64, nullable: true }) ipAddress!: string | null;
  @CreateDateColumn({ name: 'created_at', type: 'timestamptz' }) createdAt!: Date;
}

@Entity('ingestion_errors')
export class IngestionErrorEntity {
  @PrimaryGeneratedColumn('uuid') id!: string;
  @Column({ name: 'source_id', length: 100 }) sourceId!: string;
  @Column({ name: 'external_id', length: 160, nullable: true }) externalId!: string | null;
  @Column({ length: 80 }) code!: string;
  @Column({ type: 'text' }) message!: string;
  @Column({ type: 'jsonb', nullable: true }) payload!: Record<string, unknown> | null;
  @Column({ default: false }) resolved!: boolean;
  @CreateDateColumn({ name: 'created_at', type: 'timestamptz' }) createdAt!: Date;
}
