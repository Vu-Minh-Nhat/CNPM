-- PostgreSQL initial schema for production deployments.
DO $$ BEGIN CREATE TYPE users_role_enum AS ENUM ('Administrator','Operator','Technician'); EXCEPTION WHEN duplicate_object THEN NULL; END $$;
CREATE TABLE IF NOT EXISTS users (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(), email varchar(254) NOT NULL UNIQUE,
  password_hash varchar NOT NULL, role users_role_enum NOT NULL DEFAULT 'Technician', is_active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(), updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS sites (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(), code varchar(80) NOT NULL UNIQUE, name varchar(160) NOT NULL,
  address text, description text, is_active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(), updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS assets (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(), code varchar(80) NOT NULL UNIQUE, name varchar(160) NOT NULL, type varchar(100) NOT NULL,
  site_id uuid NOT NULL REFERENCES sites(id), parent_asset_id uuid REFERENCES assets(id), description text, status varchar NOT NULL DEFAULT 'active',
  created_at timestamptz NOT NULL DEFAULT now(), updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS telemetry (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(), asset_id uuid NOT NULL REFERENCES assets(id), source_id varchar(100) NOT NULL,
  external_id varchar(160) NOT NULL, metric varchar(100) NOT NULL, value double precision NOT NULL, unit varchar(40),
  recorded_at timestamptz NOT NULL, received_at timestamptz NOT NULL DEFAULT now(), is_stale boolean NOT NULL DEFAULT false,
  CONSTRAINT uq_telemetry_source_external UNIQUE(source_id, external_id)
);
CREATE INDEX IF NOT EXISTS idx_telemetry_asset_recorded ON telemetry(asset_id, recorded_at);
CREATE TABLE IF NOT EXISTS alerts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(), asset_id uuid NOT NULL REFERENCES assets(id), type varchar(100) NOT NULL,
  severity varchar(20) NOT NULL DEFAULT 'medium', message varchar(240) NOT NULL, status varchar(20) NOT NULL DEFAULT 'open',
  triggered_at timestamptz NOT NULL DEFAULT now(), resolved_at timestamptz, resolved_by uuid REFERENCES users(id)
);
CREATE TABLE IF NOT EXISTS maintenance_requests (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(), asset_id uuid NOT NULL REFERENCES assets(id), title varchar(200) NOT NULL, description text NOT NULL,
  status varchar(20) NOT NULL DEFAULT 'open', priority varchar(20) NOT NULL DEFAULT 'normal', assigned_to uuid REFERENCES users(id),
  created_by uuid NOT NULL REFERENCES users(id), due_at timestamptz, created_at timestamptz NOT NULL DEFAULT now(), updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS audit_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(), actor_id uuid REFERENCES users(id), actor_email varchar(254), action varchar(100) NOT NULL,
  resource varchar(100) NOT NULL, resource_id varchar(100), details jsonb, ip_address varchar(64), created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_audit_logs_created_at ON audit_logs(created_at);
CREATE TABLE IF NOT EXISTS ingestion_errors (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(), source_id varchar(100) NOT NULL, external_id varchar(160), code varchar(80) NOT NULL,
  message text NOT NULL, payload jsonb, resolved boolean NOT NULL DEFAULT false, created_at timestamptz NOT NULL DEFAULT now()
);
