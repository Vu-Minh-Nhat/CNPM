import { BadRequestException, Body, Controller, Get, Query, Req, Post, UsePipes, ValidationPipe } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm'; import { IsDateString, IsNumber, IsOptional, IsString, IsUUID, Length } from 'class-validator'; import { Repository } from 'typeorm';
import { Roles } from '../common/decorators/roles.decorator.js'; import { retryAsync } from '../common/retry.js'; import { ALL_ROLES, Role } from '../common/enums/role.enum.js'; import { AuditService } from '../common/audit.service.js'; import type { CurrentUser } from '../common/current-user.js'; import { AssetEntity, TelemetryEntity, IngestionErrorEntity, AlertEntity } from '../database/entities.js';
class TelemetryDto { @IsUUID() assetId!: string; @IsString() @Length(1,100) sourceId!: string; @IsString() @Length(1,160) externalId!: string; @IsString() @Length(1,100) metric!: string; @IsNumber() value!: number; @IsOptional() @IsString() unit?: string; @IsDateString() recordedAt!: string; }
@Controller('telemetry') @UsePipes(new ValidationPipe({whitelist:true,forbidNonWhitelisted:true,transform:true}))
export class TelemetryController {
 constructor(@InjectRepository(TelemetryEntity) private readonly repo:Repository<TelemetryEntity>,@InjectRepository(AssetEntity) private readonly assets:Repository<AssetEntity>,@InjectRepository(IngestionErrorEntity) private readonly errors:Repository<IngestionErrorEntity>,@InjectRepository(AlertEntity) private readonly alerts:Repository<AlertEntity>,private readonly audit:AuditService){}
 @Post() @Roles(Role.ADMINISTRATOR,Role.OPERATOR) async ingest(@Body() dto:TelemetryDto,@Req() req:any){
  const asset=await this.assets.findOne({where:{id:dto.assetId}}); if(!asset){await this.errors.save(this.errors.create({sourceId:dto.sourceId,externalId:dto.externalId,code:'ASSET_NOT_FOUND',message:'Asset không tồn tại',payload:dto as any}));throw new BadRequestException('Asset không tồn tại');}
  const recordedAt=new Date(dto.recordedAt); if(Number.isNaN(recordedAt.getTime()))throw new BadRequestException('recordedAt không hợp lệ');
  if(await this.repo.findOne({where:{sourceId:dto.sourceId,externalId:dto.externalId}})){await this.errors.save(this.errors.create({sourceId:dto.sourceId,externalId:dto.externalId,code:'DUPLICATE_EVENT',message:'Bản tin trùng lặp đã bị từ chối',payload:dto as any}));throw new BadRequestException('Bản tin trùng lặp');}
  const staleMinutes=Math.max(Number(process.env.TELEMETRY_STALE_AFTER_MINUTES)||5,1);
  const isStale=recordedAt.getTime()<Date.now()-staleMinutes*60*1000;
  const row=await retryAsync(() => this.repo.save(this.repo.create({...dto,unit:dto.unit??null,recordedAt,isStale})), 3, 200);
  if(isStale) await this.alerts.save(this.alerts.create({assetId:row.assetId,type:'STALE_TELEMETRY',severity:'medium',message:`Dữ liệu telemetry từ ${row.sourceId} đã cũ hơn ${staleMinutes} phút`,status:'open',resolvedAt:null,resolvedBy:null}));
  await this.audit.record(req.user as CurrentUser,'INGEST','telemetry',row.id,{sourceId:row.sourceId,stale:isStale},req.ip);return row;
 }
 @Get() @Roles(...ALL_ROLES) async list(@Query('assetId') assetId?:string,@Query('from') from?:string,@Query('to') to?:string,@Query('limit') limitText?:string){const limit=Math.min(Math.max(Number(limitText)||100,1),1000);const q=this.repo.createQueryBuilder('t').orderBy('t.recordedAt','DESC').take(limit);if(assetId)q.andWhere('t.assetId=:assetId',{assetId});if(from)q.andWhere('t.recordedAt>=:from',{from});if(to)q.andWhere('t.recordedAt<=:to',{to});return q.getMany()}
}
