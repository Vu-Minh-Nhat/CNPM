import { BadRequestException, Body, Controller, Delete, Get, NotFoundException, Param, Patch, Post, Req, UsePipes, ValidationPipe } from '@nestjs/common';
import { IsBoolean, IsOptional, IsString, Length } from 'class-validator';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Roles } from '../common/decorators/roles.decorator.js';
import { Role, ALL_ROLES } from '../common/enums/role.enum.js';
import { AuditService } from '../common/audit.service.js';
import type { CurrentUser } from '../common/current-user.js';
import { AssetEntity, SiteEntity } from '../database/entities.js';
class SiteDto { @IsString() @Length(1,80) code!: string; @IsString() @Length(1,160) name!: string; @IsOptional() @IsString() address?: string; @IsOptional() @IsString() description?: string; @IsOptional() @IsBoolean() isActive?: boolean; }
class UpdateSiteDto { @IsOptional() @IsString() @Length(1,80) code?: string; @IsOptional() @IsString() @Length(1,160) name?: string; @IsOptional() @IsString() address?: string | null; @IsOptional() @IsString() description?: string | null; @IsOptional() @IsBoolean() isActive?: boolean; }
@Controller('sites') @UsePipes(new ValidationPipe({ whitelist: true, forbidNonWhitelisted: true, transform: true }))
export class SitesController {
 constructor(@InjectRepository(SiteEntity) private readonly repo: Repository<SiteEntity>, @InjectRepository(AssetEntity) private readonly assets: Repository<AssetEntity>, private readonly audit: AuditService) {}
 @Get() @Roles(...ALL_ROLES) list() { return this.repo.find({ order: { name: 'ASC' } }); }
 @Get(':id') @Roles(...ALL_ROLES) async get(@Param('id') id: string) { const row = await this.repo.findOne({ where: { id } }); if (!row) throw new NotFoundException('Không tìm thấy site'); return row; }
 @Post() @Roles(Role.ADMINISTRATOR, Role.OPERATOR) async create(@Body() dto: SiteDto, @Req() req: any) { const row = await this.repo.save(this.repo.create({ ...dto, address: dto.address ?? null, description: dto.description ?? null })); await this.audit.record(req.user as CurrentUser,'CREATE','site',row.id,{code:row.code},req.ip); return row; }
 @Patch(':id') @Roles(Role.ADMINISTRATOR, Role.OPERATOR) async update(@Param('id') id: string,@Body() dto: UpdateSiteDto,@Req() req: any) { const row=await this.repo.findOne({where:{id}}); if(!row) throw new NotFoundException('Không tìm thấy site'); Object.assign(row,dto); const saved=await this.repo.save(row); await this.audit.record(req.user as CurrentUser,'UPDATE','site',id,{},req.ip); return saved; }
 @Delete(':id') @Roles(Role.ADMINISTRATOR) async remove(@Param('id') id: string,@Req() req: any) { const row=await this.repo.findOne({where:{id}}); if(!row) throw new NotFoundException('Không tìm thấy site'); if(await this.assets.exist({where:{siteId:id}})) throw new BadRequestException('Không thể xóa site đang có asset'); await this.repo.remove(row); await this.audit.record(req.user as CurrentUser,'DELETE','site',id,{code:row.code},req.ip); return {deleted:true,id}; }
}
