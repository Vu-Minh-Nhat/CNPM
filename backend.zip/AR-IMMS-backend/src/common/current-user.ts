import { createParamDecorator, ExecutionContext } from '@nestjs/common';
export interface CurrentUser { userId: string; email: string; role: string }
export const AuthUser = createParamDecorator((_data: unknown, ctx: ExecutionContext): CurrentUser => ctx.switchToHttp().getRequest().user);
