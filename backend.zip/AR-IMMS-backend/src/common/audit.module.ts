import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { AuditLogEntity } from '../database/entities.js';
import { AuditService } from './audit.service.js';
@Module({ imports: [TypeOrmModule.forFeature([AuditLogEntity])], providers: [AuditService], exports: [AuditService] })
export class AuditSharedModule {}
