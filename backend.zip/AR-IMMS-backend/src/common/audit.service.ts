import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { AuditLogEntity } from '../database/entities.js';
import type { CurrentUser } from './current-user.js';
@Injectable()
export class AuditService {
  constructor(@InjectRepository(AuditLogEntity) private readonly repo: Repository<AuditLogEntity>) {}
  async record(user: CurrentUser | undefined, action: string, resource: string, resourceId?: string, details?: Record<string, unknown>, ipAddress?: string) {
    await this.repo.save(this.repo.create({ actorId: user?.userId ?? null, actorEmail: user?.email ?? null, action, resource, resourceId: resourceId ?? null, details: details ?? null, ipAddress: ipAddress ?? null }));
  }
}
