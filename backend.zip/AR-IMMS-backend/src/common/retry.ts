/** Retries transient ingestion writes with bounded exponential backoff. */
export async function retryAsync<T>(operation: () => Promise<T>, attempts = 3, initialDelayMs = 200): Promise<T> {
  let lastError: unknown;
  for (let attempt = 0; attempt < attempts; attempt++) {
    try { return await operation(); }
    catch (error) {
      lastError = error;
      if (attempt === attempts - 1) break;
      await new Promise((resolve) => setTimeout(resolve, initialDelayMs * 2 ** attempt));
    }
  }
  throw lastError;
}
