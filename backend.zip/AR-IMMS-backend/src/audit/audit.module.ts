import { Module } from '@nestjs/common'; import { TypeOrmModule } from '@nestjs/typeorm'; import { AuditLogEntity } from '../database/entities.js'; import { AuditController } from './audit.controller.js';
@Module({imports:[TypeOrmModule.forFeature([AuditLogEntity])],controllers:[AuditController]}) export class AuditModule {}
