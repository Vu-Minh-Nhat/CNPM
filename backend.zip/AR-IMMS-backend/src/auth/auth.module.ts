import { Module } from '@nestjs/common';
import { JwtModule } from '@nestjs/jwt';
import { AuditSharedModule } from '../common/audit.module.js';
import { UsersModule } from '../users/users.module.js';
import { AuthController } from './auth.controller.js';
import { AuthService } from './auth.service.js';
import { getJwtSecret } from './jwt.config.js';
@Module({ imports: [UsersModule, AuditSharedModule, JwtModule.register({ secret: getJwtSecret(), signOptions: { expiresIn: (process.env.JWT_EXPIRES_IN ?? '1h') as any } })], controllers: [AuthController], providers: [AuthService], exports: [JwtModule, AuthService] })
export class AuthModule {}
