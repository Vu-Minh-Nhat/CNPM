import { Body, Controller, Get, HttpCode, Post, Req, UsePipes, ValidationPipe } from '@nestjs/common';
import { IsEmail, IsString, MinLength } from 'class-validator';
import { Public } from '../common/decorators/public.decorator.js';
import { Roles } from '../common/decorators/roles.decorator.js';
import { ALL_ROLES } from '../common/enums/role.enum.js';
import { AuthService } from './auth.service.js';
class LoginDto { @IsEmail() email!: string; @IsString() @MinLength(1) password!: string; }
@Controller('auth')
@UsePipes(new ValidationPipe({ whitelist: true, forbidNonWhitelisted: true, transform: true }))
export class AuthController {
  constructor(private readonly auth: AuthService) {}
  @Public() @HttpCode(200) @Post('login') login(@Body() body: LoginDto, @Req() req: any) { return this.auth.login(body.email, body.password, req.ip); }
  @Roles(...ALL_ROLES) @Get('me') me(@Req() req: any) { return req.user; }
}
