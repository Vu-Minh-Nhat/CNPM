import { CanActivate, ExecutionContext, Injectable, UnauthorizedException } from '@nestjs/common';
import { Reflector } from '@nestjs/core';
import { JwtService } from '@nestjs/jwt';
import { IS_PUBLIC_KEY } from '../common/decorators/public.decorator.js';
import { UsersService } from '../users/users.service.js';
@Injectable()
export class JwtAuthGuard implements CanActivate {
  constructor(private readonly reflector: Reflector, private readonly jwt: JwtService, private readonly users: UsersService) {}
  async canActivate(context: ExecutionContext): Promise<boolean> {
    if (this.reflector.getAllAndOverride<boolean>(IS_PUBLIC_KEY, [context.getHandler(), context.getClass()])) return true;
    const req = context.switchToHttp().getRequest();
    const [scheme, token] = String(req.headers.authorization ?? '').split(' ');
    if (scheme !== 'Bearer' || !token) throw new UnauthorizedException('Thiếu access token Bearer');
    let payload: { sub: string; email: string };
    try { payload = await this.jwt.verifyAsync(token); } catch { throw new UnauthorizedException('Token không hợp lệ hoặc đã hết hạn'); }
    if (!payload?.sub) throw new UnauthorizedException('Token không hợp lệ');
    const user = await this.users.findById(payload.sub);
    if (!user || !user.isActive) throw new UnauthorizedException('Tài khoản không tồn tại hoặc đã bị khóa');
    req.user = { userId: user.id, email: user.email, role: user.role };
    return true;
  }
}
