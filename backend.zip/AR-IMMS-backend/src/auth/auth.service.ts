import { Injectable, UnauthorizedException } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import * as bcrypt from 'bcryptjs';
import { UsersService } from '../users/users.service.js';
import { AuditService } from '../common/audit.service.js';
import type { CurrentUser } from '../common/current-user.js';
@Injectable()
export class AuthService {
  constructor(private readonly users: UsersService, private readonly jwt: JwtService, private readonly audit: AuditService) {}
  async login(email: string, password: string, ipAddress?: string) {
    if (!email || !password) throw new UnauthorizedException('Email hoặc mật khẩu không đúng');
    const user = await this.users.findByEmail(email, true);
    const valid = !!user && user.isActive && await bcrypt.compare(password, user.passwordHash);
    if (!user || !valid) { await this.audit.record(undefined, 'LOGIN_FAILED', 'auth', undefined, { email }, ipAddress); throw new UnauthorizedException('Email hoặc mật khẩu không đúng'); }
    const accessToken = await this.jwt.signAsync({ sub: user.id, email: user.email, role: user.role });
    await this.audit.record({ userId: user.id, email: user.email, role: user.role } as CurrentUser, 'LOGIN_SUCCESS', 'auth', user.id, {}, ipAddress);
    return { accessToken, tokenType: 'Bearer', expiresIn: process.env.JWT_EXPIRES_IN ?? '1h', user: { id: user.id, email: user.email, role: user.role } };
  }
}
