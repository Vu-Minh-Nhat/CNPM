import { Test, TestingModule } from '@nestjs/testing';
import { AppController } from './app.controller.js';
describe('AppController', () => {
  let controller: AppController;
  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({ controllers: [AppController] }).compile();
    controller = module.get(AppController);
  });
  it('returns API status information', () => {
    expect(controller.getHello()).toMatchObject({ name: 'AR-IMMS API', status: 'running' });
  });
});
