import { Controller, Get } from '@nestjs/common'; import { Public } from './common/decorators/public.decorator.js';
@Controller() export class AppController { @Get() @Public() getHello(){return {name:'AR-IMMS API',status:'running',docs:'See README.md for endpoints'}} }
