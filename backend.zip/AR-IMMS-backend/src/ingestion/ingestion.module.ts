import { Module } from '@nestjs/common'; import { TypeOrmModule } from '@nestjs/typeorm'; import { IngestionErrorEntity } from '../database/entities.js'; import { IngestionController } from './ingestion.controller.js';
@Module({imports:[TypeOrmModule.forFeature([IngestionErrorEntity])],controllers:[IngestionController]}) export class IngestionModule {}
