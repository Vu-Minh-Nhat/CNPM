# AR-IMMS – AI-31: Xây dựng phân quyền RBAC (ASP.NET Core 8 + PostgreSQL + JWT)

## Chạy
1. Cài .NET 8 SDK và PostgreSQL; tạo database `arimms` (hoặc sửa chuỗi kết nối trong `appsettings.json`).
2. Đặt khóa JWT (>= 32 ký tự) bằng biến môi trường: `export Jwt__Key="<chuoi-bi-mat-dai-32-ky-tu-tro-len>"`
3. `dotnet restore && dotnet run` rồi mở http://localhost:5000/swagger
4. Khi chạy lần đầu, hệ thống tự tạo bảng và 3 tài khoản thử nghiệm:
   - admin@arimms.local / Admin@123 (Administrator)
   - operator@arimms.local / Operator@123 (Operator)
   - tech@arimms.local / Tech@123 (Technician)
5. Đăng nhập `POST /api/auth/login` -> lấy `accessToken` -> bấm Authorize trên Swagger -> thử các API. Danh sách ca kiểm thử mẫu trong `requests.http`.

## Ma trận quyền
| API | Administrator | Operator | Technician |
|---|---|---|---|
| /api/users (quản lý tài khoản) | Có | Không | Không |
| GET /api/assets | Có | Có | Có |
| POST, PUT /api/assets | Có | Có | Không |
| DELETE /api/assets | Có | Không | Không |
| GET /api/telemetry | Có | Có | Có |
| PUT /api/telemetry/thresholds | Có | Có | Không |
| Tickets: tạo, phân công, đóng | Có | Có | Không |
| Tickets: cập nhật trạng thái | Không | Có | Có |

Mã phản hồi: 401 = chưa xác thực/token sai/hết hạn; 403 = đã xác thực nhưng không đủ quyền.

## Lưu ý
- Tài khoản và mật khẩu thử nghiệm chỉ dùng cho môi trường phát triển.
- Không đưa `Jwt:Key` thật vào Git.
- Khi dùng EF Core migrations, thay `EnsureCreatedAsync()` trong `DbSeeder` bằng `MigrateAsync()`.
