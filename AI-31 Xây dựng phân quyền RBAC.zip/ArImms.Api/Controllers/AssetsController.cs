using ArImms.Api.Auth;
using ArImms.Api.Data;
using ArImms.Api.Dtos;
using ArImms.Api.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace ArImms.Api.Controllers;

/// <summary>F05–F10 – Xem: cả 3 vai trò. Thêm/sửa: Administrator, Operator. Xóa: Administrator.</summary>
[ApiController]
[Route("api/assets")]
public class AssetsController : ControllerBase
{
    private readonly AppDbContext _db;
    public AssetsController(AppDbContext db) => _db = db;

    [HttpGet]
    [Authorize(Roles = AppRoles.AllRoles)]
    public async Task<IEnumerable<Asset>> GetAll() => await _db.Assets.AsNoTracking().ToListAsync();

    [HttpGet("{id:guid}")]
    [Authorize(Roles = AppRoles.AllRoles)]
    public async Task<ActionResult<Asset>> GetById(Guid id)
    {
        var asset = await _db.Assets.AsNoTracking().FirstOrDefaultAsync(a => a.Id == id);
        return asset is null ? NotFound() : Ok(asset);
    }

    [HttpPost]
    [Authorize(Roles = AppRoles.AdminOrOperator)]
    public async Task<IActionResult> Create(AssetRequest req)
    {
        if (await _db.Assets.AnyAsync(a => a.Code == req.Code)) return Conflict(new { message = "Mã tài sản đã tồn tại" });
        var asset = new Asset { Code = req.Code, Name = req.Name, Type = req.Type, Status = req.Status };
        _db.Assets.Add(asset);
        await _db.SaveChangesAsync();
        return CreatedAtAction(nameof(GetById), new { id = asset.Id }, asset);
    }

    [HttpPut("{id:guid}")]
    [Authorize(Roles = AppRoles.AdminOrOperator)]
    public async Task<IActionResult> Update(Guid id, AssetRequest req)
    {
        var asset = await _db.Assets.FindAsync(id);
        if (asset is null) return NotFound();
        asset.Code = req.Code; asset.Name = req.Name; asset.Type = req.Type; asset.Status = req.Status;
        await _db.SaveChangesAsync();
        return Ok(asset);
    }

    [HttpDelete("{id:guid}")]
    [Authorize(Roles = AppRoles.Administrator)]
    public async Task<IActionResult> Delete(Guid id)
    {
        var asset = await _db.Assets.FindAsync(id);
        if (asset is null) return NotFound();
        _db.Assets.Remove(asset);
        await _db.SaveChangesAsync();
        return NoContent();
    }
}
