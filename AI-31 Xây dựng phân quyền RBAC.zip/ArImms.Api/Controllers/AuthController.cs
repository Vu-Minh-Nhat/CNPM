using ArImms.Api.Auth;
using ArImms.Api.Data;
using ArImms.Api.Dtos;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace ArImms.Api.Controllers;

[ApiController]
[Route("api/auth")]
public class AuthController : ControllerBase
{
    private readonly AppDbContext _db;
    private readonly ITokenService _tokens;
    public AuthController(AppDbContext db, ITokenService tokens) { _db = db; _tokens = tokens; }

    /// <summary>Đăng nhập – endpoint duy nhất không cần JWT.</summary>
    [AllowAnonymous]
    [HttpPost("login")]
    public async Task<ActionResult<LoginResponse>> Login(LoginRequest req)
    {
        var user = await _db.Users.FirstOrDefaultAsync(u => u.Email == req.Email);
        // Cùng một thông báo cho mọi lỗi để không lộ tài khoản có tồn tại hay không.
        if (user is null || !user.IsActive || !BCrypt.Net.BCrypt.Verify(req.Password, user.PasswordHash))
            return Unauthorized(new { message = "Sai email hoặc mật khẩu" });

        var (token, expires) = _tokens.CreateToken(user);
        return Ok(new LoginResponse(token, expires, user.Role));
    }

    /// <summary>Xem thông tin người đang đăng nhập (mọi vai trò).</summary>
    [Authorize(Roles = AppRoles.AllRoles)]
    [HttpGet("me")]
    public IActionResult Me() => Ok(new
    {
        id = User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value,
        email = User.FindFirst(System.Security.Claims.ClaimTypes.Email)?.Value,
        role = User.FindFirst(System.Security.Claims.ClaimTypes.Role)?.Value
    });
}
