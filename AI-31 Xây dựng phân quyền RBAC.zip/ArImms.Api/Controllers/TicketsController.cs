using ArImms.Api.Auth;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace ArImms.Api.Controllers;

/// <summary>Khung phân quyền cho ticket – logic thật sẽ bổ sung ở Sprint sau.</summary>
[ApiController]
[Route("api/tickets")]
public class TicketsController : ControllerBase
{
    [HttpGet]
    [Authorize(Roles = AppRoles.AllRoles)]
    public IActionResult List() => Ok(new { message = "Danh sách ticket (placeholder)" });

    [HttpPost]
    [Authorize(Roles = AppRoles.AdminOrOperator)]
    public IActionResult Create() => Ok(new { message = "Tạo ticket (placeholder)" });

    [HttpPatch("{id:guid}/assign")]
    [Authorize(Roles = AppRoles.AdminOrOperator)]
    public IActionResult Assign(Guid id) => Ok(new { message = "Phân công kỹ thuật viên (placeholder)" });

    [HttpPatch("{id:guid}/status")]
    [Authorize(Roles = AppRoles.OperatorOrTechnician)]
    public IActionResult UpdateStatus(Guid id) => Ok(new { message = "Cập nhật trạng thái xử lý (placeholder)" });

    [HttpPatch("{id:guid}/close")]
    [Authorize(Roles = AppRoles.AdminOrOperator)]
    public IActionResult Close(Guid id) => Ok(new { message = "Duyệt đóng ticket (placeholder)" });
}
