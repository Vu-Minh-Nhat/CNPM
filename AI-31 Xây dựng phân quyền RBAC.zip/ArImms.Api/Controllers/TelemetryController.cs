using ArImms.Api.Auth;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace ArImms.Api.Controllers;

/// <summary>Khung phân quyền cho telemetry/cảnh báo – logic thật sẽ bổ sung ở Sprint sau.</summary>
[ApiController]
[Route("api/telemetry")]
public class TelemetryController : ControllerBase
{
    [HttpGet]
    [Authorize(Roles = AppRoles.AllRoles)]
    public IActionResult GetLatest() => Ok(new { message = "Telemetry (placeholder)" });

    [HttpPut("thresholds")]
    [Authorize(Roles = AppRoles.AdminOrOperator)]
    public IActionResult SetThresholds() => Ok(new { message = "Cập nhật ngưỡng cảnh báo (placeholder)" });
}
