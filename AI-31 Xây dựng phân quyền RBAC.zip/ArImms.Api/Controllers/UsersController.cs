using ArImms.Api.Auth;
using ArImms.Api.Data;
using ArImms.Api.Dtos;
using ArImms.Api.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace ArImms.Api.Controllers;

/// <summary>F02/F03 – Chỉ Administrator quản lý tài khoản và gán vai trò.</summary>
[ApiController]
[Route("api/users")]
[Authorize(Roles = AppRoles.Administrator)]
public class UsersController : ControllerBase
{
    private readonly AppDbContext _db;
    public UsersController(AppDbContext db) => _db = db;

    [HttpGet]
    public async Task<IEnumerable<UserDto>> GetAll() =>
        await _db.Users.AsNoTracking()
            .Select(u => new UserDto(u.Id, u.Email, u.Role, u.IsActive)).ToListAsync();

    [HttpPost]
    public async Task<IActionResult> Create(CreateUserRequest req)
    {
        if (!AppRoles.IsValid(req.Role)) return BadRequest(new { message = "Vai trò không hợp lệ" });
        if (await _db.Users.AnyAsync(u => u.Email == req.Email)) return Conflict(new { message = "Email đã tồn tại" });

        var user = new User
        {
            Email = req.Email,
            Role = req.Role,
            PasswordHash = BCrypt.Net.BCrypt.HashPassword(req.Password)
        };
        _db.Users.Add(user);
        await _db.SaveChangesAsync();
        return Created($"api/users/{user.Id}", new UserDto(user.Id, user.Email, user.Role, user.IsActive));
    }

    [HttpPut("{id:guid}/role")]
    public async Task<IActionResult> ChangeRole(Guid id, UpdateRoleRequest req)
    {
        if (!AppRoles.IsValid(req.Role)) return BadRequest(new { message = "Vai trò không hợp lệ" });
        var user = await _db.Users.FindAsync(id);
        if (user is null) return NotFound();
        user.Role = req.Role;
        await _db.SaveChangesAsync();
        return Ok(new UserDto(user.Id, user.Email, user.Role, user.IsActive));
    }

    [HttpPut("{id:guid}/deactivate")]
    public async Task<IActionResult> Deactivate(Guid id)
    {
        var user = await _db.Users.FindAsync(id);
        if (user is null) return NotFound();
        user.IsActive = false;
        await _db.SaveChangesAsync();
        return NoContent();
    }
}
