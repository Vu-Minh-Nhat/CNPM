namespace ArImms.Api.Auth;

/// <summary>Ba vai trò của hệ thống AR-IMMS.</summary>
public static class AppRoles
{
    public const string Administrator = "Administrator";
    public const string Operator = "Operator";
    public const string Technician = "Technician";

    public const string AdminOrOperator = Administrator + "," + Operator;
    public const string OperatorOrTechnician = Operator + "," + Technician;
    public const string AllRoles = Administrator + "," + Operator + "," + Technician;

    public static readonly string[] All = { Administrator, Operator, Technician };
    public static bool IsValid(string? role) => role is not null && All.Contains(role);
}
