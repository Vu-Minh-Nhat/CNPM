using ArImms.Api.Auth;
using ArImms.Api.Models;
using Microsoft.EntityFrameworkCore;

namespace ArImms.Api.Data;

/// <summary>Tạo 3 tài khoản thử nghiệm (mỗi vai trò một tài khoản). Chỉ dùng cho môi trường dev.</summary>
public static class DbSeeder
{
    public static async Task SeedAsync(AppDbContext db)
    {
        await db.Database.EnsureCreatedAsync();   // Khi dùng migration, đổi thành MigrateAsync()
        if (await db.Users.AnyAsync()) return;

        db.Users.AddRange(
            new User { Email = "admin@arimms.local", Role = AppRoles.Administrator, PasswordHash = BCrypt.Net.BCrypt.HashPassword("Admin@123") },
            new User { Email = "operator@arimms.local", Role = AppRoles.Operator, PasswordHash = BCrypt.Net.BCrypt.HashPassword("Operator@123") },
            new User { Email = "tech@arimms.local", Role = AppRoles.Technician, PasswordHash = BCrypt.Net.BCrypt.HashPassword("Tech@123") });
        await db.SaveChangesAsync();
    }
}
