using System.ComponentModel.DataAnnotations;

namespace ArImms.Api.Dtos;

public record LoginRequest([Required, EmailAddress] string Email, [Required] string Password);
public record LoginResponse(string AccessToken, DateTime ExpiresAt, string Role);

public record CreateUserRequest(
    [Required, EmailAddress] string Email,
    [Required, MinLength(8)] string Password,
    [Required] string Role);

public record UpdateRoleRequest([Required] string Role);

public record UserDto(Guid Id, string Email, string Role, bool IsActive);

public record AssetRequest([Required, MaxLength(64)] string Code, [Required, MaxLength(200)] string Name, string Type, string Status);
