namespace ArImms.Api.Models;

/// <summary>Tài sản hạ tầng (rút gọn) – dùng để minh họa phân quyền CRUD.</summary>
public class Asset
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public string Code { get; set; } = "";
    public string Name { get; set; } = "";
    public string Type { get; set; } = "Server";  // Site | Room | Rack | Server | Container
    public string Status { get; set; } = "Active";
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
}
