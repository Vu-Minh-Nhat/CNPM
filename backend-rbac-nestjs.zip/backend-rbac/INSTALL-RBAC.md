# Cài đặt RBAC (AI-31) vào backend NestJS

1. npm install @nestjs/jwt bcryptjs
2. Copy thư mục src/ và test/ vào project, ĐÈ lên src/app.module.ts và src/app.controller.ts
   (hai file này đã gộp sẵn code gốc của bạn, phần thêm có chú thích // [RBAC]).
3. Mở src/health/*.controller.ts, thêm @Public() lên controller (hoặc method) để /health
   vẫn gọi được không cần token:
     import { Public } from ../common/decorators/public.decorator.js;
     @Public()
     @Controller(health)
4. Đặt biến môi trường JWT_SECRET (production bắt buộc).
5. npm run start:dev  và  npm run test:e2e
