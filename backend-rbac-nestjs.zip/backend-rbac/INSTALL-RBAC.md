# Cài đặt RBAC (AI-31) vào backend NestJS

1. Cài thư viện:
   npm install @nestjs/jwt bcryptjs
2. Copy thư mục `src/` và `test/` trong gói này vào project (giữ nguyên đường dẫn).
3. app.module.ts: nếu đã có file, chỉ thêm 3 phần đánh dấu [RBAC]; không ghi đè.
4. AppController mặc định của NestJS (GET /) sẽ bị chặn do deny-by-default:
   thêm @Public() lên controller đó hoặc xóa nó đi.
5. Đặt biến môi trường JWT_SECRET (production bắt buộc).
6. Chạy: npm run start:dev   và   npm run test:e2e
