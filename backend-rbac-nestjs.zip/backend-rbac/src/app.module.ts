// LƯU Ý: đây là file MẪU. Nếu app.module.ts của bạn đã có (ví dụ ObserveModule.forRoot(...)),
// KHÔNG ghi đè – chỉ thêm 3 phần được đánh dấu [RBAC] vào file hiện có.
import { Module } from "@nestjs/common";
import { APP_GUARD } from "@nestjs/core";
import { AssetsModule } from "./assets/assets.module.js";            // [RBAC] 1. import
import { AuthModule } from "./auth/auth.module.js";                  // [RBAC] 1. import
import { JwtAuthGuard } from "./auth/jwt-auth.guard.js";             // [RBAC] 1. import
import { RolesGuard } from "./auth/roles.guard.js";                  // [RBAC] 1. import
import { UsersModule } from "./users/users.module.js";               // [RBAC] 1. import

@Module({
  imports: [
    // ...các module có sẵn của bạn (ObserveModule, v.v.)
    AuthModule, UsersModule, AssetsModule,                           // [RBAC] 2. imports
  ],
  providers: [
    // Thứ tự quan trọng: xác thực JWT (401) chạy trước, rồi mới kiểm tra vai trò (403).
    { provide: APP_GUARD, useClass: JwtAuthGuard },                  // [RBAC] 3. providers
    { provide: APP_GUARD, useClass: RolesGuard },                    // [RBAC] 3. providers
  ],
})
export class AppModule {}
