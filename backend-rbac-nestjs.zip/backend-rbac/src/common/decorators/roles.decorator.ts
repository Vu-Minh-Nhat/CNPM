import { SetMetadata } from "@nestjs/common";
import { Role } from "../enums/role.enum.js";

export const ROLES_KEY = "roles";

/** Khai báo các vai trò được phép gọi endpoint (đặt trên class hoặc trên method). */
export const Roles = (...roles: Role[]) => SetMetadata(ROLES_KEY, roles);
