import { SetMetadata } from '@nestjs/common';

export const IS_PUBLIC_KEY = 'isPublic';

/** Endpoint không cần JWT (ví dụ: đăng nhập). */
export const Public = () => SetMetadata(IS_PUBLIC_KEY, true);
