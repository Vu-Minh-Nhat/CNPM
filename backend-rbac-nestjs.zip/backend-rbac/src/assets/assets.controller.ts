import { Controller, Delete, Get, Post, Put } from "@nestjs/common";
import { Roles } from "../common/decorators/roles.decorator.js";
import { ALL_ROLES, Role } from "../common/enums/role.enum.js";

/**
 * Mẫu áp dụng RBAC cho API tài sản.
 * Xem: cả 3 vai trò | Thêm/sửa: Administrator, Operator | Xóa: Administrator.
 * Thay phần trả về bằng AssetsService khi có logic thật.
 */
@Controller("assets")
export class AssetsController {
  @Get()
  @Roles(...ALL_ROLES)
  findAll() {
    return { message: "Danh sách tài sản (demo)" };
  }

  @Post()
  @Roles(Role.ADMINISTRATOR, Role.OPERATOR)
  create() {
    return { message: "Tạo tài sản (demo)" };
  }

  @Put(":id")
  @Roles(Role.ADMINISTRATOR, Role.OPERATOR)
  update() {
    return { message: "Cập nhật tài sản (demo)" };
  }

  @Delete(":id")
  @Roles(Role.ADMINISTRATOR)
  remove() {
    return { message: "Xóa tài sản (demo)" };
  }
}
