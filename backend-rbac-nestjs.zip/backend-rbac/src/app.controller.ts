import { Controller, Get } from '@nestjs/common';
import { AppService } from './app.service.js';
import { Public } from './common/decorators/public.decorator.js'; // [RBAC]

@Controller()
export class AppController {
  constructor(private readonly appService: AppService) {}

  @Public() // [RBAC] cho phép gọi GET / không cần đăng nhập
  @Get()
  getHello(): string {
    return this.appService.getHello();
  }
}
