import os
from dotenv import load_dotenv

load_dotenv()

BACKEND_URL = os.getenv("BACKEND_URL", "http://localhost:5000/api/telemetry")
AGENT_TOKEN = os.getenv("AGENT_TOKEN", "mini-dc-super-secret-token-2026")
NODE_ID = os.getenv("NODE_ID", "node-testbed-01")
