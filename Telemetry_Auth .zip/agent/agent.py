import requests
import psutil
import time
from config import BACKEND_URL, AGENT_TOKEN, NODE_ID

def push_telemetry():
    payload = {
        "node_id": NODE_ID,
        "cpu_percent": psutil.cpu_percent(interval=1),
        "ram_percent": psutil.virtual_memory().percent,
        "disk_percent": psutil.disk_usage('/').percent
    }
    
    headers = {
        "X-Agent-Token": AGENT_TOKEN,
        "Content-Type": "application/json"
    }
    
    try:
        response = requests.post(BACKEND_URL, json=payload, headers=headers)
        if response.status_code == 200:
            print(f"[Agent] Gửi telemetry thành công: {payload}")
        else:
            print(f"[Agent] Lỗi xác thực: {response.status_code} - {response.text}")
    except Exception as e:
        print(f"[Agent] Không thể kết nối tới Backend: {e}")

if __name__ == "__main__":
    print(f"Bắt đầu Agent cho Node: {NODE_ID}")
    while True:
        push_telemetry()
        time.sleep(5) # Gửi 5 giây 1 lần
