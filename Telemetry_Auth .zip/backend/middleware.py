from functools import wraps
from flask import request, jsonify
import os

# Registry mô phỏng CSDL lưu trữ Token liên kết với Node và Trạng thái (Active/Revoked)
AGENT_REGISTRY = {
    "mini-dc-super-secret-token-2026": {
        "node_id": "node-testbed-01",
        "active": True
    },
    "token-cua-node-02": {
        "node_id": "node-testbed-02",
        "active": False # Đã bị vô hiệu hóa
    }
}

def require_agent_auth(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        token = request.headers.get("X-Agent-Token")
        
        # 1. Kiểm tra thiếu token
        if not token:
            return jsonify({"error": "Unauthorized: Thiếu thông tin xác thực (Token)"}), 401
            
        agent_info = AGENT_REGISTRY.get(token)
        
        # 2. Kiểm tra sai token
        if not agent_info:
            return jsonify({"error": "Forbidden: Token không tồn tại hoặc sai"}), 403
            
        # 3. Kiểm tra quyền vô hiệu hóa (Tiêu chí: Tác nhân bị vô hiệu hóa không gửi được)
        if not agent_info.get("active"):
            return jsonify({"error": "Forbidden: Tác nhân (Agent) này đã bị vô hiệu hóa"}), 403
            
        # Gắn node_id được phép vào request để controller xử lý tiếp
        request.allowed_node_id = agent_info["node_id"]
        
        return f(*args, **kwargs)
    return decorated_function
