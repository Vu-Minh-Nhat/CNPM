from flask import Flask, request, jsonify
from middleware import require_agent_auth

app = Flask(__name__)

@app.route('/api/telemetry', methods=['POST'])
@require_agent_auth
def receive_telemetry():
    data = request.get_json()
    
    if not data or 'node_id' not in data:
        return jsonify({"error": "Dữ liệu payload không hợp lệ"}), 400
        
    claimed_node_id = data.get('node_id')
    
    # 4. Kiểm tra giả mạo Node (Tiêu chí: Tác nhân không được gửi thay thế Nút khác)
    if claimed_node_id != request.allowed_node_id:
        print(f"[CẢNH BÁO BẢO MẬT] Token của '{request.allowed_node_id}' đang cố gửi dữ liệu giả mạo cho '{claimed_node_id}'")
        return jsonify({"error": f"Forbidden: Agent không có quyền gửi dữ liệu cho Node '{claimed_node_id}'"}), 403
        
    print(f"[Backend] Đã nhận dữ liệu hợp lệ từ {claimed_node_id}: {data}")
    
    return jsonify({
        "status": "success",
        "message": f"Đã tiếp nhận telemetry cho node: {claimed_node_id}"
    }), 200

if __name__ == "__main__":
    app.run(host='0.0.0.0', port=5000, debug=True)
